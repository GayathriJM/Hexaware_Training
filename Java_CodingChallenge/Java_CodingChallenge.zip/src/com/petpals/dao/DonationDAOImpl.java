package com.petpals.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.petpals.entity.CashDonation;
import com.petpals.entity.Donation;
import com.petpals.entity.ItemDonation;

public class DonationDAOImpl implements DonationDAO {
	private Connection connection;

    public DonationDAOImpl(Connection connection) {
    	 this.connection =connection;
    }

    @Override
    public void addDonation(Donation donation) {
        String query = "INSERT INTO donations (donorName, amount, donationType, donationDate, itemType) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, donation.getDonorName());
            statement.setDouble(2, donation.getAmount());
            
            if (donation instanceof CashDonation) {
                statement.setString(3, "cash");
                statement.setTimestamp(4, Timestamp.valueOf(((CashDonation) donation).getDonationDate()));
                statement.setString(5, null); 
            } else if (donation instanceof ItemDonation) {
                statement.setString(3, "item");
                statement.setTimestamp(4, null);
                statement.setString(5, ((ItemDonation) donation).getItemType());
            }
            statement.executeUpdate();
        } catch (SQLException e) {
        	System.err.println("Error adding donation: " + e.getMessage());
        }
    }


    @Override
    public List<Donation> getAllDonations() {
        List<Donation> donations = new ArrayList<>();
        String query = "SELECT * FROM donations";
        try (Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                String donorName = resultSet.getString("donorName");
                double amount = resultSet.getDouble("amount");
                String donationType = resultSet.getString("donationType");

                if ("cash".equalsIgnoreCase(donationType)) {
                    Timestamp timestamp = resultSet.getTimestamp("donationDate");
                    donations.add(new CashDonation(donorName, amount, timestamp.toLocalDateTime()));
                } else if ("item".equalsIgnoreCase(donationType)) {
                    String itemType = resultSet.getString("itemType");
                    donations.add(new ItemDonation(donorName, amount, itemType));
                }
            }
        } catch (SQLException e) {
        	System.err.println("Error getting donation: " + e.getMessage());
        }
        return donations;
    }

}
