package com.petpals.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.petpals.entity.AdoptionEvent;
import com.petpals.entity.Participant;


public class AdoptionEventDAOImpl implements AdoptionEventDAO {
	private Connection connection;

    public AdoptionEventDAOImpl(Connection connection) {
    	this.connection = connection;
    }

    @Override
    public void addEvent(AdoptionEvent event) {
        String query = "INSERT INTO adoptionEvents (eventName, eventDate) VALUES (?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, event.getEventName());
            statement.setDate(2, Date.valueOf(event.getEventDate()));
            statement.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error adding event: " + e.getMessage());
        }
    }

    @Override
    public AdoptionEvent getEventById(int eventId) {
        String query = "SELECT * FROM adoptionEvents WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, eventId);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                String eventName = resultSet.getString("eventName");
                Date eventDate = resultSet.getDate("eventDate");
                return new AdoptionEvent(eventId, eventName, eventDate.toLocalDate());
            }
        } catch (SQLException e) {
            System.err.println("Error fetching event: " + e.getMessage());
        }
        return null;
    }
    
    @Override
    public List<AdoptionEvent> getAllEvents() {
        List<AdoptionEvent> events = new ArrayList<>();
        String query = "SELECT * FROM adoptionEvents";
        try (Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                int eventId = resultSet.getInt("id");
                String eventName = resultSet.getString("eventName");
                Date eventDate = resultSet.getDate("eventDate");
                events.add(new AdoptionEvent(eventId, eventName, eventDate.toLocalDate()));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching events: " + e.getMessage());
        }
        return events;
    }
    
    @Override
    public void registerParticipant(String eventName, String participantName, String participantType) {
        String findEventSQL = "SELECT id FROM adoptionEvents WHERE eventName = ?";
        String insertSQL = "INSERT INTO participants (eventId, participantName, participantType) VALUES (?, ?, ?)";

        try (PreparedStatement findStmt = connection.prepareStatement(findEventSQL)) {
            findStmt.setString(1, eventName);
            ResultSet rs = findStmt.executeQuery();

            if (rs.next()) {
                int eventId = rs.getInt("id");
                try (PreparedStatement insertStmt = connection.prepareStatement(insertSQL)) {
                    insertStmt.setInt(1, eventId);
                    insertStmt.setString(2, participantName);
                    insertStmt.setString(3, participantType); 
                    int rows = insertStmt.executeUpdate();
                    if (rows > 0) {
                        System.out.println("Participant (" + participantType + ") registered successfully.");
                    }
                }
            } else {
                System.out.println("Event not found.");
            }
        } catch (SQLException e) {
            System.err.println("Error registering participant: " + e.getMessage());
        }
    }
    
    @Override
    public List<Participant> getParticipantsForEvent(int eventId) {
        List<Participant> participants = new ArrayList<>();
        String query = "SELECT * FROM participants WHERE eventId = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, eventId);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String participantName = resultSet.getString("participantName");
                String participantType = resultSet.getString("participantType");
                participants.add(new Participant(id, eventId, participantName, participantType));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching participants: " + e.getMessage());
        }
        return participants;
    }
}
