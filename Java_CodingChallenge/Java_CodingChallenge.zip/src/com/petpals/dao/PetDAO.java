package com.petpals.dao;

import java.util.List;
import com.petpals.entity.Pet;

public interface PetDAO {
    void addPet(Pet pet);
    void removePet(String name);
    Pet getPetById(int id);
    List<Pet> getAllPets();
    void updatePet(Pet pet);
}
