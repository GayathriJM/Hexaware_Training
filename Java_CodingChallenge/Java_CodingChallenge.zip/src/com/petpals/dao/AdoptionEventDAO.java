package com.petpals.dao;

import java.util.List;

import com.petpals.entity.AdoptionEvent;
import com.petpals.entity.Participant;

public interface AdoptionEventDAO {
	 void addEvent(AdoptionEvent event);  
	    AdoptionEvent getEventById(int eventId);  
	    List<AdoptionEvent> getAllEvents();  
	    
	    void registerParticipant(String eventName, String participantName, String participantType); 
	    List<Participant> getParticipantsForEvent(int eventId);
}