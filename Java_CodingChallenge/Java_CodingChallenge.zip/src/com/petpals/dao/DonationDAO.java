package com.petpals.dao;

import java.util.List;

import com.petpals.entity.Donation;

public interface DonationDAO {
	void addDonation(Donation donation);
    List<Donation> getAllDonations();
}
