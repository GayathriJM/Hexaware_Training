package com.petpals.dao;

import java.sql.*;
import java.util.*;

import com.petpals.entity.Cat;
import com.petpals.entity.Dog;
import com.petpals.entity.Pet;

public class PetDAOImpl implements PetDAO {
    private Connection connection;

    public PetDAOImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public void addPet(Pet pet) {
        String query = "INSERT INTO pets (name, age, breed, type, dogBreed, catColor) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, pet.getName());
            statement.setInt(2, pet.getAge());
            statement.setString(3, pet.getBreed());
            statement.setString(4, pet instanceof Dog ? "dog" : "cat");
            statement.setString(5, pet instanceof Dog ? ((Dog) pet).getDogBreed() : null);
            statement.setString(6, pet instanceof Cat ? ((Cat) pet).getCatColor() : null);
            statement.executeUpdate();
            System.out.println("Pet added to database.");
        } catch (SQLException e) {
            System.out.println("Error adding pet: " + e.getMessage());
        }
    }

    @Override
    public void removePet(String name) {
        String sql = "DELETE FROM pets WHERE name = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, name);
            int rows = stmt.executeUpdate();
            if (rows > 0) {
                System.out.println("Pet removed from database.");
            } else {
                System.out.println("No pet found with the name: " + name);
            }
        } catch (SQLException e) {
            System.out.println("Error removing pet: " + e.getMessage());
        }
    }
    
    @Override
    public Pet getPetById(int petId) {
        String query = "SELECT * FROM pets WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, petId);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                String name = resultSet.getString("name");
                int age = resultSet.getInt("age");
                String breed = resultSet.getString("breed");
                String type = resultSet.getString("type");

                if ("dog".equalsIgnoreCase(type)) {
                    String dogBreed = resultSet.getString("dogBreed");
                    return new Dog(petId, name, age, breed, dogBreed);
                } else if ("cat".equalsIgnoreCase(type)) {
                    String catColor = resultSet.getString("catColor");
                    return new Cat(petId, name, age, breed, catColor);
                }
            }
        } catch (SQLException e) {
        	 System.out.println("Error getting pet: " + e.getMessage());
        }
        return null;
    }

    @Override
    public List<Pet> getAllPets() {
        List<Pet> pets = new ArrayList<>();
        String sql = "SELECT * FROM pets";
        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
            	int id = rs.getInt("id");
                String type = rs.getString("type");
                String name = rs.getString("name");
                int age = rs.getInt("age");
                String breed = rs.getString("breed");

                if ("Dog".equalsIgnoreCase(type)) {
                    String dogBreed = rs.getString("dogBreed");
                    pets.add(new Dog(id, name, age, breed, dogBreed));
                } else if ("Cat".equalsIgnoreCase(type)) {
                    String catColor = rs.getString("catColor");
                    pets.add(new Cat(id, name, age, breed, catColor));
                } else {
                    pets.add(new Pet(id, name, age, breed));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving pets: " + e.getMessage());
        }
        return pets;
    }
    
    @Override
    public void updatePet(Pet pet) {
        String query = "UPDATE pets SET name = ?, age = ?, breed = ?, dogBreed = ?, catColor = ? WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, pet.getName());
            statement.setInt(2, pet.getAge());
            statement.setString(3, pet.getBreed());
            statement.setString(4, pet instanceof Dog ? ((Dog) pet).getDogBreed() : null);
            statement.setString(5, pet instanceof Cat ? ((Cat) pet).getCatColor() : null);
            statement.setInt(6, pet.getId());
            statement.executeUpdate();
        } catch (SQLException e) {
        	System.out.println("Error updating pet: " + e.getMessage());
        }
    }
}
