package com.petpals.main;

import java.sql.Connection;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Scanner;
import java.io.*;
import com.petpals.dao.DonationDAO;
import com.petpals.dao.DonationDAOImpl;
import com.petpals.dao.AdoptionEventDAO;
import com.petpals.dao.AdoptionEventDAOImpl;
import com.petpals.entity.AdoptionEvent;
import com.petpals.entity.CashDonation;
import com.petpals.entity.Cat;
import com.petpals.entity.Dog;
import com.petpals.entity.ItemDonation;
import com.petpals.entity.Pet;
import com.petpals.exception.AdoptionException;
import com.petpals.exception.FileReadException;
import com.petpals.exception.InsufficientFundsException;
import com.petpals.exception.InvalidPetAgeException;
import com.petpals.exception.NullPetPropertyException;
import com.petpals.util.DBConnUtil;
import com.petpals.dao.PetDAO;
import com.petpals.dao.PetDAOImpl;

public class App {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Connection connection = null;

        try {
            connection = DBConnUtil.getConnection("src/db.properties");
            PetDAO petDao = new PetDAOImpl(connection); 
            DonationDAO donationDao = new DonationDAOImpl(connection);
            AdoptionEventDAO eventDao = new AdoptionEventDAOImpl(connection);

            while (true) {
                System.out.println("\nMenu:");
                System.out.println("1. Add Pet\n2. Remove Pet\n3. List Pets\n4. Record Donation\n5. List Adoption Events\n6. Register for Event\n7. Load Pets From File\n8. Adopt Pet\n9. Exit");
                System.out.print("Enter your choice: ");
                int choice = sc.nextInt(); 
                sc.nextLine();
                
                switch (choice) {
                    case 1:
                        try {
                            System.out.print("Enter pet type (Dog/Cat): ");
                            String type = sc.nextLine();

                            System.out.print("Enter pet name: ");
                            String petName = sc.nextLine();

                            System.out.print("Enter age: ");
                            int age = sc.nextInt();
                            sc.nextLine();

                            if (age <= 0) throw new InvalidPetAgeException("Age must be positive.");

                            System.out.print("Enter breed: ");
                            String breed = sc.nextLine();

                            Pet pet;
                            if (type.equalsIgnoreCase("Dog")) {
                                System.out.print("Enter dog breed: ");
                                String dogBreed = sc.nextLine();
                                pet = new Dog(0, petName, age, breed, dogBreed);
                            } else if (type.equalsIgnoreCase("Cat")) {
                                System.out.print("Enter cat color: ");
                                String catColor = sc.nextLine();
                                pet = new Cat(0, petName, age, breed, catColor);
                            } else {
                                throw new AdoptionException("Invalid pet type. Only Dog or Cat allowed.");
                            }

                            petDao.addPet(pet);
                        } catch (InvalidPetAgeException | AdoptionException e) {
                            System.out.println(e.getMessage());
                        }
                        break;

                    case 2:
                        System.out.print("Enter pet name to remove: ");
                        String removeName = sc.nextLine();
                        petDao.removePet(removeName);
                        break;

                    case 3:
                        for (Pet p : petDao.getAllPets()) {
                            try {
                                if (p.getName() == null || p.getBreed() == null) {
                                    throw new NullPetPropertyException("Pet has missing info.");
                                }
                                System.out.println(p);
                            } catch (NullPetPropertyException e) {
                                System.out.println(e.getMessage());
                            }
                        }
                        break;

                    case 4:
                    	try {
                            System.out.print("Enter donor name: ");
                            String donor = sc.nextLine();

                            System.out.print("Enter amount: ");
                            double amount = sc.nextDouble();
                            sc.nextLine();

                            if (amount < 10) {
                            	throw new InsufficientFundsException("Minimum donation is $10.");
                            }

                            System.out.print("Cash or Item donation? ");
                            String donationType = sc.nextLine();

                            if (donationType.equalsIgnoreCase("Cash")) {
                                CashDonation cd = new CashDonation(donor, amount, LocalDateTime.now());
                                donationDao.addDonation(cd); 
                                System.out.println("Cash recorded successfully");
                            } else {
                                System.out.print("Enter item type: ");
                                String item = sc.nextLine();
                                ItemDonation id = new ItemDonation(donor, amount, item);
                                donationDao.addDonation(id);
                                System.out.println("Item recorded successfully");
                            }
                        } catch (Exception e) {
                            System.out.println(e.getMessage());
                        }
                        break;

                    case 5:
                        List<AdoptionEvent> events = eventDao.getAllEvents();
                        if (events.isEmpty()) {
                            System.out.println("No events found.");
                        } else {
                            System.out.println("List of Adoption Events:");
                            for (AdoptionEvent event : events) {
                                System.out.println(event);
                            }
                        }
                        break;

                    case 6:
                        System.out.print("Enter event name: ");
                        String event = sc.nextLine();

                        System.out.print("Enter your name: ");
                        String participant = sc.nextLine();

                        System.out.print("Enter participant type (Adopter/Shelter): ");
                        String type = sc.nextLine();

                        eventDao.registerParticipant(event, participant, type);
                        break;

                    case 7:
                    	try {
                            File file = new File("pets.txt");
                            Scanner fileScanner = new Scanner(file);

                            while (fileScanner.hasNextLine()) {
                                String line = fileScanner.nextLine();
                                String[] parts = line.split(",");
                                if (parts.length == 5 && parts[0].equalsIgnoreCase("Dog")) {
                                    petDao.addPet(new Dog(
                                            Integer.parseInt(parts[1]),  
                                            parts[2],                     
                                            Integer.parseInt(parts[3]),   
                                            parts[4],                     
                                            "BreedInfo"                
                                    ));
                                } else if (parts.length == 5 && parts[0].equalsIgnoreCase("Cat")) {
                                    petDao.addPet(new Cat(
                                            Integer.parseInt(parts[1]), 
                                            parts[2],                     
                                            Integer.parseInt(parts[3]),   
                                            parts[4],                   
                                            "ColorInfo"                   
                                    ));
                                }
                            }
                            fileScanner.close();
                            System.out.println("Pets loaded from file.");
                        } catch (FileNotFoundException e) {
                            try {
                                throw new FileReadException("pets.txt not found.");
                            } catch (FileReadException fre) {
                                System.out.println(fre.getMessage());
                            }
                        }
                        break;
                    case 8:
                        try {
                            System.out.print("Enter pet name to adopt: ");
                            String adoptName = sc.nextLine();
                            Pet found = null;

                            for (Pet p : petDao.getAllPets()) {
                                if (p.getName().equalsIgnoreCase(adoptName)) {
                                    found = p;
                                    break;
                                }
                            }

                            if (found == null) {
                                throw new AdoptionException("Pet not available for adoption.");
                            }

                            petDao.removePet(adoptName);
                            System.out.println("Adoption successful! Welcome your new friend: " + found.getName());

                        } catch (AdoptionException e) {
                            System.out.println(e.getMessage());
                        }
                        break;

                    case 9:
                        System.out.println("Exiting application.");
                        return;

                    default:
                        System.out.println("Invalid option.");
                }
            }
        } catch (Exception e) {
            System.out.println("Application error: " + e.getMessage());
        } finally {
            try {
                if (connection != null) connection.close();
            } catch (Exception e) {
                System.out.println("Error closing connection: " + e.getMessage());
            }
        }
    }

}
