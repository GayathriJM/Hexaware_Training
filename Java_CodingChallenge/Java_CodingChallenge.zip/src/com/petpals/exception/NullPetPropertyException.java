package com.petpals.exception;

public class NullPetPropertyException extends Exception {
    public NullPetPropertyException(String message) {
        super(message);
    }
}