package com.petpals.entity;

public class Dog extends Pet {
    private String dogBreed;

    public Dog(int id, String name, int age, String breed, String dogBreed) {
        super(id,name, age, breed);
        this.dogBreed = dogBreed;
    }

    public String getDogBreed() { return dogBreed; }
    public void setDogBreed(String dogBreed) { this.dogBreed = dogBreed; }
    
    @Override
    public void adopt() {
        System.out.println("Dog " + getName() + " has been adopted!");
    }

    @Override
    public String toString() {
        return "Dog [name=" + getName() + ", age=" + getAge() + ", breed=" + getBreed() +
               ", dogBreed=" + dogBreed + "]";
    }

}




