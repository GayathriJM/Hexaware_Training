package com.petpals.entity;

public interface IAdoptable {
    void adopt();
}

