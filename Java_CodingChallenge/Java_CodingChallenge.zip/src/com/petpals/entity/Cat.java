package com.petpals.entity;

public class Cat extends Pet {
    private String catColor;

    public Cat(int id, String name, int age, String breed, String catColor) {
        super(id, name, age, breed);
        this.catColor = catColor;
    }

    public String getCatColor() { return catColor; }
    public void setCatColor(String catColor) { this.catColor = catColor; }
    
    @Override
    public void adopt() {
        System.out.println("Cat " + getName() + " has been adopted!");
    }
    
    @Override
    public String toString() {
        return "Cat [name=" + getName() + ", age=" + getAge() + ", breed=" + getBreed() +
               ", catColor=" + catColor + "]";
    }

}