package com.petpals.entity;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class AdoptionEvent {
	private int eventId;
    private String eventName;
    private LocalDate eventDate;
    private List<IAdoptable> adoptableParticipants = new ArrayList<>();
    private List<Participant> participants = new ArrayList<>();
    
    public AdoptionEvent() {}

    public AdoptionEvent(int eventId, String eventName, LocalDate eventDate) {
        this.eventId = eventId;
        this.eventName = eventName;
        this.eventDate = eventDate;
    }

    public int getEventId() {
        return eventId;
    }

    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public LocalDate getEventDate() {
        return eventDate;
    }

    public void setEventDate(LocalDate eventDate) {
        this.eventDate = eventDate;
    }

    public List<Participant> getParticipants() {
		return participants;
	}

	public void setParticipants(List<Participant> participants) {
		this.participants = participants;
	}

	public void registerParticipant(IAdoptable participant) {
    	adoptableParticipants.add(participant);
    }

    public void hostEvent() {
        System.out.println("Hosting Adoption Event with participants: " + adoptableParticipants.size());
    }

    @Override
    public String toString() {
        return "Event ID: " + eventId + ", Name: " + eventName + ", Date: " + eventDate;
    }

}

