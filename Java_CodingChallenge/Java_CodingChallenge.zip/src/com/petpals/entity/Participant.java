package com.petpals.entity;

public class Participant {
    private int id;
    private int eventId;
    private String participantName;
    private String participantType;
    
    public Participant() {}

    public Participant(int id, int eventId, String participantName, String participantType) {
        this.id = id;
        this.eventId = eventId;
        this.participantName = participantName;
        this.participantType = participantType;
    }

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getEventId() {
		return eventId;
	}
	public void setEventId(int eventId) {
		this.eventId = eventId;
	}
	public String getParticipantName() {
		return participantName;
	}
	public void setParticipantName(String participantName) {
		this.participantName = participantName;
	}
	public String getParticipantType() {
		return participantType;
	}
	public void setParticipantType(String participantType) {
		this.participantType = participantType;
	}
	
	@Override
	public String toString() {
		return "Participant [id=" + id + ", eventId=" + eventId + ", participantName=" + participantName
				+ ", participantType=" + participantType + "]";
	}

}
