package com.sis.entity;

import java.util.Date;

import com.sis.entity.Student;

public class Payment {
 private int paymentId;
 private Student student; 
 private double amount;
 private Date paymentDate;

 public Payment(int paymentId, Student student, double amount, Date paymentDate) {
     this.paymentId = paymentId;
     this.student = student;
     this.amount = (amount < 0) ? 0 : amount;
     this.paymentDate = paymentDate;
 }

 public int getPaymentId() {
	 return paymentId; 
 }
 public Student getStudent() {
	 return student; 
 }  
 public double getAmount() {
	 return amount; 
 }
 public Date getPaymentDate() {
	 return paymentDate; 
 }

 public void setStudent(Student student) {
	 this.student = student; 
 }
 public void setAmount(double amount) {
	 if (amount < 0) {
		 System.out.println("Invalid amount! Setting amount to 0.");
		 this.amount = 0;
		 } 
	 else {
		 this.amount = amount;
		 } 
 }
 public void setPaymentDate(Date paymentDate) {
	 this.paymentDate = paymentDate; 
 }
}
