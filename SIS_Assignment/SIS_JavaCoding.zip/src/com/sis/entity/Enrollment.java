package com.sis.entity;

import java.util.Date;

import com.sis.entity.Course;
import com.sis.entity.Student;

public class Enrollment {
 private int enrollmentId;
 private Student student; 
 private Course course;   
 private Date enrollmentDate;

 public Enrollment(int enrollmentId, Student student, Course course, Date enrollmentDate) {
     this.enrollmentId = enrollmentId;
     this.student = student;
     this.course = course;
     this.enrollmentDate = enrollmentDate;
 }

 public int getEnrollmentId() {
	 return enrollmentId; 
 }
 public Student getStudent() {
	 return student; 
 }
 public Course getCourse() {
	 return course; 
 }
 public Date getEnrollmentDate() {
	 return enrollmentDate; 
 }

 public void setStudent(Student student) {
	 this.student = student; 
 }
 public void setCourse(Course course) {
	 this.course = course; 
 }
 public void setEnrollmentDate(Date enrollmentDate) {
	 this.enrollmentDate = enrollmentDate; 
 }
 }


