package com.sis.entity;

import java.util.ArrayList;
import java.util.List;

public class Course{
    private int courseId;
    private String courseName;
    private String courseCode;
    private int credits;
    private Teacher teacher;
    private List<Student> enrolledStudents;

    public Course(int courseId, String courseName, String courseCode, int credits, Teacher teacher) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.courseCode = courseCode;
        this.credits = credits;
        this.teacher = teacher;
        this.enrolledStudents = new ArrayList<>();
    }

    public Course() {
        this.enrolledStudents = new ArrayList<>();
    }

    public int getCourseId() {
        return courseId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getCourseCode() {
        return courseCode;
    }

    public void setCourseCode(String courseCode) {
        this.courseCode = courseCode;
    }

    public int getCredits() {
        return credits;
    }

    public void setCredits(int credits) {
        this.credits = credits;
    }

    public Teacher getTeacher() {
        return teacher;
    }

    public void setTeacher(Teacher teacher) {
        this.teacher = teacher;
    }

    public List<Student> getEnrollments() {
        return enrolledStudents;
    }

    public void assignTeacher(Teacher teacher) {
        this.teacher = teacher;
        //System.out.println("Teacher " + teacher.getName() + " has been assigned to course " + courseName);
    }

    public void updateCourseInfo(String courseCode, String courseName, int credits, Teacher teacher) {
        this.courseCode = courseCode;
        this.courseName = courseName;
        this.credits = credits;
        this.teacher = teacher;
    }

    public void displayCourseInfo() {
        System.out.println("Course ID: " + courseId);
        System.out.println("Course Name: " + courseName);
        System.out.println("Course Code: " + courseCode);
        System.out.println("Credits: " + credits);
        System.out.println("Instructor: " + (teacher != null ? teacher.getName() : "Not Assigned"));
    }
    
    @Override
    public String toString() {
        return "Course ID: " + courseId + 
               ", Name: " + courseName + 
               ", Code: " + courseCode + 
               ", Credits: " + credits + 
               ", Teacher: " + (teacher != null ? teacher.getTeacherId() : "Not Assigned");
    }
}
