package com.sis.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Student {
    private int studentId;
    private String firstName;
    private String lastName;
    private Date dateOfBirth;
    private String email;
    private String phoneNumber;
    private List<Course> enrolledCourses;
    private List<Payment> paymentHistory;

    public Student(int studentId, String firstName, String lastName, Date dateOfBirth, String email, String phoneNumber) {
        this.studentId = studentId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.enrolledCourses = new ArrayList<>();
        this.paymentHistory = new ArrayList<>();
    }
    public Student() {
        this.enrolledCourses = new ArrayList<>();
        this.paymentHistory = new ArrayList<>();
    }



    public int getStudentId() { 
    	return studentId; 
    }
    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }
    public String getFirstName() {
    	return firstName; 
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getLastName() {
    	return lastName; 
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public Date getDateOfBirth() {
    	return dateOfBirth; 
    }
    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }
    public String getEmail() {
    	return email; 
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getPhoneNumber() {
    	return phoneNumber; 
    }
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    public List<Course> getEnrolledCourses() {
        return enrolledCourses;
    }

    public List<Payment> getPaymentHistory() {
        return paymentHistory;
    }
    
    public void enrollInCourse(Course course) {
        enrolledCourses.add(course);
        System.out.println(firstName + " has been enrolled in " + course.getCourseName());
    }

    public void updateStudentInfo(String firstName, String lastName, Date dateOfBirth, String email, String phoneNumber) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
        this.email = email;
        this.phoneNumber = phoneNumber;
        System.out.println("Student information updated successfully.");
    }

    public void makePayment(double amount, Date paymentDate) {
        Payment payment = new Payment(paymentHistory.size() + 1, this, amount, paymentDate);
        paymentHistory.add(payment);
        System.out.println("Payment of Rs." + amount + " recorded successfully.");
    }
    
    public void displayStudentInfo() {
        System.out.println("Student ID: " + studentId);
        System.out.println("Name: " + firstName + " " + lastName);
        System.out.println("Date of Birth: " + dateOfBirth);
        System.out.println("Email: " + email);
        System.out.println("Phone: " + phoneNumber);
    }

    @Override
    public String toString() {
        return "Student ID: " + studentId +
               ", Name: " + firstName + " " + lastName +
               ", DOB: " + dateOfBirth +
               ", Email: " + email +
               ", Phone: " + phoneNumber;
    }
}
