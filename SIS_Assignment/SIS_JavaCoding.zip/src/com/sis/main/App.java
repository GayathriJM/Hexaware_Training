package com.sis.main;

import com.sis.util.DatabaseConnection;
import com.sis.dao.StudentDAO;
import com.sis.dao.StudentDAOImpl;
import com.sis.dao.CourseDAO;
import com.sis.dao.CourseDAOImpl;
import com.sis.entity.Student;
import com.sis.entity.Course;
import com.sis.entity.Teacher;
import com.sis.exception.CourseNotFoundException;
import com.sis.exception.InvalidStudentDataException;
import com.sis.exception.InvalidTeacherDataException;
import com.sis.exception.InvalidCourseDataException;
import com.sis.exception.TeacherNotFoundException;
import com.sis.exception.StudentNotFoundException;
import com.sis.exception.DuplicateEnrollmentException;
import com.sis.exception.InvalidEnrollmentDataException;
import com.sis.exception.PaymentValidationException;

import com.sis.dao.EnrollmentDAO;
import com.sis.dao.EnrollmentDAOImpl;
import com.sis.entity.Enrollment;
import com.sis.dao.TeacherDAO;
import com.sis.dao.TeacherDAOImpl;
import com.sis.dao.PaymentDAO;
import com.sis.dao.PaymentDAOImpl;
import com.sis.entity.Payment;

import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class App {
	public static void main(String[] args) {
		DatabaseConnection.getConnection();
		Scanner scanner = new Scanner(System.in);
		StudentDAO studentDAO = new StudentDAOImpl();
		CourseDAO courseDAO = new CourseDAOImpl();
		EnrollmentDAO enrollmentDAO = new EnrollmentDAOImpl();
		TeacherDAO teacherDAO = new TeacherDAOImpl();
		PaymentDAO paymentDAO = new PaymentDAOImpl();

		while (true) {
			System.out.println("\n========= Student Information System =========");
			System.out.println("1. Student Management");
			System.out.println("2. Course Management");
			System.out.println("3. Enrollment Management");
			System.out.println("4. Teacher Management");
			System.out.println("5. Payment Management");
			System.out.println("6. Exit");
			System.out.print("Enter your choice: ");
			int mainChoice = scanner.nextInt();
			scanner.nextLine(); // consume newline

			switch (mainChoice) {
			case 1:
				studentManagementMenu(scanner, studentDAO);
				break;
			case 2:
				courseManagementMenu(scanner, courseDAO);
				break;
			case 3:
				enrollmentManagementMenu(scanner, enrollmentDAO, studentDAO, courseDAO);
				break;
			case 4:
				teacherManagementMenu(scanner, teacherDAO);
				break;
			case 5:
				paymentManagementMenu(scanner, paymentDAO, studentDAO);
				break;
			case 6:
				System.out.println("Exiting...");
				scanner.close();
				System.exit(0);
				break;
			default:
				System.out.println("Invalid choice! Please try again.");
			}
		}
	}

	private static void studentManagementMenu(Scanner scanner, StudentDAO studentDAO) {
		while (true) {
			System.out.println("\n----- Student Management -----");
			System.out.println("1. Add Student");
			System.out.println("2. View All Students");
			System.out.println("3. Get Student By ID");
			System.out.println("4. Update Student");
			System.out.println("5. Delete Student");
			System.out.println("6. Return to Main Menu");
			System.out.print("Enter your choice: ");
			int choice = scanner.nextInt();
			scanner.nextLine();

			switch (choice) {
			case 1: // Add Student
				try {
					System.out.print("Enter First Name: ");
					String firstName = scanner.nextLine();
					System.out.print("Enter Last Name: ");
					String lastName = scanner.nextLine();
					System.out.print("Enter Date of Birth (yyyy-mm-dd): ");
					String dob = scanner.nextLine();
					System.out.print("Enter Email: ");
					String email = scanner.nextLine();
					System.out.print("Enter Phone Number: ");
					String phoneNumber = scanner.nextLine();

					Student newStudent = new Student(0, firstName, lastName, java.sql.Date.valueOf(dob), email,
							phoneNumber);
					studentDAO.addStudent(newStudent);
					System.out.println("Student added successfully!");
				} catch (InvalidStudentDataException e) {
					System.out.println("Error: " + e.getMessage());
				}
				break;
			case 2: // View All Students
				List<Student> students = studentDAO.getAllStudents();
				System.out.println("Student List:");
				for (Student student : students) {
					System.out.println(student);
				}
				break;

			case 3: // Get Student by ID
				System.out.print("Enter Student ID: ");
				int studentId = scanner.nextInt();
				Student fetchedStudent = studentDAO.getStudentById(studentId);
				if (fetchedStudent != null) {
					System.out.println("Student Details: " + fetchedStudent);
				} else {
					System.out.println("Student not found.");
				}
				break;

			case 4: // Update Student
				try {
					System.out.print("Enter Student ID to update: ");
					int updateId = scanner.nextInt();
					scanner.nextLine(); // consume newline
					Student existingStudent = studentDAO.getStudentById(updateId);
					if (existingStudent != null) {
						System.out.println("Student found. Enter new details (leave blank to keep existing values).");
						System.out.print("Enter new First Name: ");
						String newFirstName = scanner.nextLine();
						if (!newFirstName.trim().isEmpty()) {
							existingStudent.setFirstName(newFirstName);
						}
						System.out.print("Enter new Last Name: ");
						String newLastName = scanner.nextLine();
						if (!newLastName.trim().isEmpty()) {
							existingStudent.setLastName(newLastName);
						}
						System.out.print("Enter new Date of Birth (yyyy-mm-dd): ");
						String newDob = scanner.nextLine();
						if (!newDob.trim().isEmpty()) {
							existingStudent.setDateOfBirth(java.sql.Date.valueOf(newDob));
						}
						System.out.print("Enter new Email: ");
						String newEmail = scanner.nextLine();
						if (!newEmail.trim().isEmpty()) {
							existingStudent.setEmail(newEmail);
						}
						System.out.print("Enter new Phone Number: ");
						String newPhone = scanner.nextLine();
						if (!newPhone.trim().isEmpty()) {
							existingStudent.setPhoneNumber(newPhone);
						}
						studentDAO.updateStudent(existingStudent);
						System.out.println("Student updated successfully!");
					} else {
						System.out.println("Student not found.");
					}
				} catch (InvalidStudentDataException e) {
					System.out.println("Error updating student: " + e.getMessage());
				}
				break;

			case 5: // Delete Student
				System.out.print("Enter Student ID to delete: ");
				int deleteId = scanner.nextInt();
				studentDAO.deleteStudent(deleteId);
				System.out.println("Student deleted successfully!");
				break;
			case 6:
				return;
			default:
				System.out.println("Invalid choice.");
			}
		}
	}

	// ========== COURSE MENU ==========
	private static void courseManagementMenu(Scanner scanner, CourseDAO courseDAO) {
		while (true) {
			System.out.println("\n----- Course Management -----");
			System.out.println("1. Add Course");
			System.out.println("2. View All Courses");
			System.out.println("3. Get Course By ID");
			System.out.println("4. Update Course");
			System.out.println("5. Delete Course");
			System.out.println("6. Return to Main Menu");
			System.out.print("Enter your choice: ");
			int choice = scanner.nextInt();
			scanner.nextLine();

			switch (choice) {
			case 1: // Add Course
				try {
					System.out.print("Enter Course Name: ");
					String courseName = scanner.nextLine();
					System.out.print("Enter Course Code: ");
					String courseCode = scanner.nextLine();
					System.out.print("Enter Credits: ");
					int credits = scanner.nextInt();
					scanner.nextLine(); // consume newline
					System.out.print("Enter Teacher ID: ");
					int teacherId = scanner.nextInt();
					scanner.nextLine(); // consume newline
					Teacher teacher = new Teacher(teacherId);
					Course newCourse = new Course(0, courseName, courseCode, credits, teacher);
					courseDAO.addCourse(newCourse);
				} catch (InvalidCourseDataException | TeacherNotFoundException e) {
					System.out.println("Error adding course: " + e.getMessage());
				}
				break;

			case 2: // View All Courses
				List<Course> courses = courseDAO.getAllCourses();
				System.out.println("Course List:");
				for (Course course : courses) {
					System.out.println(course);
				}
				break;

			case 3: // Get Course by ID
				try {
					System.out.print("Enter Course ID: ");
					int courseId = scanner.nextInt();
					scanner.nextLine(); // consume newline

					Course fetchedCourse = courseDAO.getCourseById(courseId);
					if (fetchedCourse != null) {
						System.out.println("Course Details: " + fetchedCourse);
					}
				} catch (CourseNotFoundException e) {
					System.out.println("Error: " + e.getMessage());
				}
				break;

			case 4: // Update Course
				System.out.print("Enter Course ID to update: ");
				int updateCourseId = scanner.nextInt();
				scanner.nextLine(); // Consume newline

				try {
					Course courseToUpdate = courseDAO.getCourseById(updateCourseId);
					if (courseToUpdate != null) {
						System.out.print("Enter new Course Name: ");
						String newCourseName = scanner.nextLine();

						System.out.print("Enter new Course Code: ");
						String newCourseCode = scanner.nextLine();

						System.out.print("Enter new Credits: ");
						int newCredits = scanner.nextInt();
						scanner.nextLine(); // Consume newline

						System.out.print("Enter new Teacher ID (or 0 to skip): ");
						int newTeacherId = scanner.nextInt();
						scanner.nextLine(); // Consume newline

						if (newTeacherId != 0) {
							Teacher updatedTeacher = new Teacher(newTeacherId);
							courseToUpdate.setTeacher(updatedTeacher);
						} else {
							courseToUpdate.setTeacher(null); // Optional: unassign teacher
						}

						courseToUpdate.setCourseName(newCourseName);
						courseToUpdate.setCourseCode(newCourseCode);
						courseToUpdate.setCredits(newCredits);

						courseDAO.updateCourse(courseToUpdate);
						System.out.println("Course updated successfully.");
					}
				} catch (CourseNotFoundException e) {
					System.out.println(e.getMessage());
				} catch (Exception e) {
					System.out.println("Error updating course: " + e.getMessage());
				}
				break;

			case 5: // Delete Course
				try {
					System.out.print("Enter Course ID to delete: ");
					int deleteCourseId = scanner.nextInt();
					scanner.nextLine(); // consume newline

					courseDAO.deleteCourse(deleteCourseId);
					System.out.println("Course deleted successfully!");
				} catch (CourseNotFoundException e) {
					System.out.println("Error: " + e.getMessage());
				}
				break;
			case 6:
				return;
			default:
				System.out.println("Invalid choice.");
			}
		}
	}

	// ========== ENROLLMENT MENU ==========
	private static void enrollmentManagementMenu(Scanner scanner, EnrollmentDAO enrollmentDAO, StudentDAO studentDAO,
			CourseDAO courseDAO) {
		while (true) {
			System.out.println("\n----- Enrollment Management -----");
			System.out.println("1. Enroll Student");
			System.out.println("2. View All Enrollments");
			System.out.println("3. Get Enrollment By Student ID");
			System.out.println("4. Get Enrollment By Course ID");
			System.out.println("5. Update Enrollment");
			System.out.println("6. Delete Enrollment");
			System.out.println("7. Return to Main Menu");
			System.out.print("Enter your choice: ");
			int choice = scanner.nextInt();
			scanner.nextLine();

			try {
				switch (choice) {
				case 1: // Add Enrollment
					try {
						System.out.print("Enter Student ID: ");
						int stuId = scanner.nextInt();
						System.out.print("Enter Course ID: ");
						int courId = scanner.nextInt();
						scanner.nextLine(); // consume newline

						Student stu = studentDAO.getStudentById(stuId);
						Course cou = courseDAO.getCourseById(courId);

						if (stu != null && cou != null) {
							Enrollment newEnrollment = new Enrollment(0, stu, cou, new Date());
							enrollmentDAO.addEnrollment(newEnrollment);
							System.out.println("Enrollment added successfully.");
						} else {
							System.out.println("Student or Course not found.");
						}
					} catch (StudentNotFoundException | CourseNotFoundException | DuplicateEnrollmentException
							| InvalidEnrollmentDataException e) {
						System.out.println("Error: " + e.getMessage());
					}
					break;

				case 2: // View All Enrollments
					List<Enrollment> allEnrollments = enrollmentDAO.getAllEnrollments();
					for (Enrollment enr : allEnrollments) {
						System.out.println("Enrollment ID: " + enr.getEnrollmentId() + ", Student ID: "
								+ enr.getStudent().getStudentId() + ", Course ID: " + enr.getCourse().getCourseId()
								+ ", Date: " + enr.getEnrollmentDate());
					}
					break;

				case 3: // Get Enrollments by Student ID
					System.out.print("Enter Student ID: ");
					int stuIdFilter = scanner.nextInt();
					List<Enrollment> byStudent = enrollmentDAO.getEnrollmentsByStudentId(stuIdFilter);
					for (Enrollment enr : byStudent) {
						System.out.println("Enrollment ID: " + enr.getEnrollmentId() + ", Course Name: "
								+ enr.getCourse().getCourseName() + ", Enrolled on: " + enr.getEnrollmentDate());
					}
					break;

				case 4: // Get Enrollments by Course ID
					System.out.print("Enter Course ID: ");
					int courIdFilter = scanner.nextInt();
					List<Enrollment> byCourse = enrollmentDAO.getEnrollmentsByCourseId(courIdFilter);
					for (Enrollment enr : byCourse) {
						System.out.println("Enrollment ID: " + enr.getEnrollmentId() + ", Student Name: "
								+ enr.getStudent().getFirstName() + " " + enr.getStudent().getLastName()
								+ ", Enrolled on: " + enr.getEnrollmentDate());
					}
					break;

				case 5: // Update Enrollment
					try {
						System.out.print("Enter Enrollment ID to update: ");
						int updEnrollId = scanner.nextInt();

						System.out.print("Enter new Student ID: ");
						int newStuId = scanner.nextInt();
						System.out.print("Enter new Course ID: ");
						int newCouId = scanner.nextInt();
						scanner.nextLine(); // Consume newline

						Student updStu = studentDAO.getStudentById(newStuId); // also throws?
						Course updCou = courseDAO.getCourseById(newCouId); // throws CourseNotFoundException

						if (updStu != null && updCou != null) {
							Enrollment updatedEnrollment = new Enrollment(updEnrollId, updStu, updCou, new Date());
							enrollmentDAO.updateEnrollment(updatedEnrollment); // may throw
							System.out.println("Enrollment updated successfully.");
						} else {
							System.out.println("Student or Course not found.");
						}

					} catch (CourseNotFoundException | InvalidEnrollmentDataException e) {
						System.out.println("Error: " + e.getMessage());
					}
					break;

				case 6: // Delete Enrollment
					try {
						System.out.print("Enter Enrollment ID to delete: ");
						int deleteEnrId = scanner.nextInt();
						enrollmentDAO.deleteEnrollment(deleteEnrId);
						System.out.println("Enrollment deleted if ID existed.");
					} catch (InvalidEnrollmentDataException e) {
						System.out.println("Error: " + e.getMessage());
					}
					break;
				case 7:
					return;
				default:
					System.out.println("Invalid choice.");
				}
			} catch (Exception e) {
				System.out.println("Error: " + e.getMessage());
			}
		}
	}

	// ========== TEACHER MENU ==========
	private static void teacherManagementMenu(Scanner scanner, TeacherDAO teacherDAO) {
		while (true) {
			System.out.println("\n----- Teacher Management -----");
			System.out.println("1. Add Teacher");
			System.out.println("2. View All Teachers");
			System.out.println("3. Get Teacher By ID");
			System.out.println("4. Update Teacher");
			System.out.println("5. Delete Teacher");
			System.out.println("6. Return to Main Menu");
			System.out.print("Enter your choice: ");
			int choice = scanner.nextInt();
			scanner.nextLine();

			try {
				switch (choice) {
				case 1: // Add Teacher
					try {
						System.out.print("Enter First Name: ");
						String tFirstName = scanner.nextLine();
						System.out.print("Enter Last Name: ");
						String tLastName = scanner.nextLine();
						System.out.print("Enter Email: ");
						String tEmail = scanner.nextLine();
						System.out.print("Enter Expertise: ");
						String tExpertise = scanner.nextLine();
						Teacher newTeacher = new Teacher(0, tFirstName, tLastName, tEmail, tExpertise);
						teacherDAO.addTeacher(newTeacher);
						System.out.println("Teacher added successfully!");
					} catch (InvalidTeacherDataException e) {
						System.out.println("Error: " + e.getMessage());
					}
					break;

				case 2: // View All Teachers
					List<Teacher> teachers = teacherDAO.getAllTeachers();
					System.out.println("Teacher List:");
					for (Teacher t : teachers) {
						System.out.println(t);
					}
					break;

				case 3: // Get Teacher by ID
					try {
						System.out.print("Enter Teacher ID: ");
						int teacherId = scanner.nextInt();
						scanner.nextLine(); // consume newline
						Teacher fetchedTeacher = teacherDAO.getTeacherById(teacherId);
						System.out.println("Teacher Details: " + fetchedTeacher);
					} catch (TeacherNotFoundException e) {
						System.out.println("Error: " + e.getMessage());
					}
					break;

				case 4: // Update Teacher
					try {
						System.out.print("Enter Teacher ID to update: ");
						int updateTeacherId = scanner.nextInt();
						scanner.nextLine();
						Teacher existingTeacher = teacherDAO.getTeacherById(updateTeacherId);

						System.out.println("Teacher found. Enter new details (leave blank to keep existing values).");

						System.out.print("Enter new First Name: ");
						String updatedFirstName = scanner.nextLine();
						if (!updatedFirstName.trim().isEmpty()) {
							existingTeacher.setFirstName(updatedFirstName);
						}

						System.out.print("Enter new Last Name: ");
						String updatedLastName = scanner.nextLine();
						if (!updatedLastName.trim().isEmpty()) {
							existingTeacher.setLastName(updatedLastName);
						}

						System.out.print("Enter new Email: ");
						String updatedEmail = scanner.nextLine();
						if (!updatedEmail.trim().isEmpty()) {
							existingTeacher.setEmail(updatedEmail);
						}

						System.out.print("Enter new Expertise: ");
						String updatedExpertise = scanner.nextLine();
						if (!updatedExpertise.trim().isEmpty()) {
							existingTeacher.setExpertise(updatedExpertise);
						}

						teacherDAO.updateTeacher(existingTeacher);
						System.out.println("Teacher updated successfully!");

					} catch (TeacherNotFoundException | InvalidTeacherDataException e) {
						System.out.println("Error: " + e.getMessage());
					}
					break;

				case 5: // Delete Teacher
					try {
						System.out.print("Enter Teacher ID to delete: ");
						int deleteTeacherId = scanner.nextInt();
						scanner.nextLine(); // consume newline
						teacherDAO.deleteTeacher(deleteTeacherId);
						System.out.println("Teacher deleted if ID existed.");
					} catch (TeacherNotFoundException e) {
						System.out.println("Error: " + e.getMessage());
					}
					break;
				case 6:
					return;
				default:
					System.out.println("Invalid choice.");
				}
			} catch (Exception e) {
				System.out.println("Error: " + e.getMessage());
			}
		}
	}

	// ========== PAYMENT MENU ==========
	private static void paymentManagementMenu(Scanner scanner, PaymentDAO paymentDAO, StudentDAO studentDAO) {
		while (true) {
			System.out.println("\n----- Payment Management -----");
			System.out.println("1. Add Payment");
			System.out.println("2. View All Payments");
			System.out.println("3. Get Payment By ID");
			System.out.println("4. Update Payment");
			System.out.println("5. Delete Payment");
			System.out.println("6. Return to Main Menu");
			System.out.print("Enter your choice: ");
			int choice = scanner.nextInt();
			scanner.nextLine();

			try {
				switch (choice) {
				case 1:
					try {
						System.out.print("Enter Student ID: ");
						int payStuId = scanner.nextInt();
						scanner.nextLine(); // consume newline
						Student payStudent = studentDAO.getStudentById(payStuId);
						if (payStudent != null) {
							System.out.print("Enter Payment Amount: ");
							double amount = scanner.nextDouble();
							scanner.nextLine();
							Payment newPayment = new Payment(0, payStudent, amount, new Date());
							paymentDAO.addPayment(newPayment);
							System.out.println("Payment added successfully!");
						} else {
							System.out.println("Student not found.");
						}
					} catch (StudentNotFoundException | PaymentValidationException e) {
						System.out.println("Error: " + e.getMessage());
					}
					break;

				case 2: // View All Payments
					try {
						List<Payment> payments = paymentDAO.getAllPayments();
						for (Payment p : payments) {
							System.out.println(
									"Payment ID: " + p.getPaymentId() + ", Student ID: " + p.getStudent().getStudentId()
											+ ", Amount: " + p.getAmount() + ", Date: " + p.getPaymentDate());
						}
					} catch (PaymentValidationException e) {
						System.out.println("Error retrieving payments: " + e.getMessage());
					}
					break;

				case 3:
					try {
						System.out.print("Enter Payment ID: ");
						int pid = scanner.nextInt();
						scanner.nextLine();
						Payment fetchedPayment = paymentDAO.getPaymentById(pid);
						System.out.println("Payment ID: " + fetchedPayment.getPaymentId() + ", Student ID: "
								+ fetchedPayment.getStudent().getStudentId() + ", Amount: " + fetchedPayment.getAmount()
								+ ", Date: " + fetchedPayment.getPaymentDate());
					} catch (PaymentValidationException e) {
						System.out.println("Error: " + e.getMessage());
					}
					break;

				case 4:
					try {
						System.out.print("Enter Payment ID to update: ");
						int updatePaymentId = scanner.nextInt();
						scanner.nextLine();
						Payment existingPayment = paymentDAO.getPaymentById(updatePaymentId);
						System.out.print("Enter new Student ID (current: " + existingPayment.getStudent().getStudentId()
								+ "): ");
						int newStudentId = scanner.nextInt();
						scanner.nextLine();
						System.out.print("Enter new Amount (current: " + existingPayment.getAmount() + "): ");
						double newAmount = scanner.nextDouble();
						scanner.nextLine();
						System.out.print("Enter new Payment Date (yyyy-mm-dd, current: "
								+ existingPayment.getPaymentDate() + "): ");
						String newDateStr = scanner.nextLine();

						Student updatedStudent = studentDAO.getStudentById(newStudentId);
						if (updatedStudent != null) {
							existingPayment.setStudent(updatedStudent);
							existingPayment.setAmount(newAmount);
							existingPayment.setPaymentDate(java.sql.Date.valueOf(newDateStr));
							paymentDAO.updatePayment(existingPayment);
							System.out.println("Payment updated successfully!");
						} else {
							System.out.println("Invalid Student ID!");
						}
					} catch (StudentNotFoundException | PaymentValidationException e) {
						System.out.println("Error: " + e.getMessage());
					}
					break;

				case 5:
					try {
						System.out.print("Enter Payment ID to delete: ");
						int deletePaymentId = scanner.nextInt();
						scanner.nextLine();
						paymentDAO.deletePayment(deletePaymentId);
						System.out.println("Payment deleted successfully!");
					} catch (PaymentValidationException e) {
						System.out.println("Error: " + e.getMessage());
					}
					break;
				case 6:
					return;
				default:
					System.out.println("Invalid choice.");
				}
			} catch (Exception e) {
				System.out.println("Error: " + e.getMessage());
			}
		}
	}
}
