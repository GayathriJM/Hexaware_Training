package com.sis.dao;

import com.sis.entity.Enrollment;
import com.sis.exception.CourseNotFoundException;
import com.sis.exception.DuplicateEnrollmentException;
import com.sis.exception.InvalidEnrollmentDataException;
import com.sis.exception.StudentNotFoundException;

import java.util.List;

public interface EnrollmentDAO {
    void addEnrollment(Enrollment enrollment) throws DuplicateEnrollmentException, CourseNotFoundException, StudentNotFoundException, InvalidEnrollmentDataException;
    Enrollment getEnrollmentById(int enrollmentId) throws InvalidEnrollmentDataException;
    List<Enrollment> getAllEnrollments();
    void updateEnrollment(Enrollment enrollment) throws InvalidEnrollmentDataException;
    void deleteEnrollment(int enrollmentId) throws InvalidEnrollmentDataException;

    List<Enrollment> getEnrollmentsByStudentId(int studentId);
    List<Enrollment> getEnrollmentsByCourseId(int courseId);
}
