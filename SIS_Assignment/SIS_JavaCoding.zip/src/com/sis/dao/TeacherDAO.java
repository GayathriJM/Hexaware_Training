package com.sis.dao;

import com.sis.entity.Teacher;
import com.sis.exception.InvalidTeacherDataException;
import com.sis.exception.TeacherNotFoundException;

import java.util.List;

public interface TeacherDAO {
    void addTeacher(Teacher teacher) throws InvalidTeacherDataException;
    Teacher getTeacherById(int teacherId) throws TeacherNotFoundException;
    List<Teacher> getAllTeachers();
    void updateTeacher(Teacher teacher) throws InvalidTeacherDataException, TeacherNotFoundException;
    void deleteTeacher(int teacherId) throws TeacherNotFoundException;
}
