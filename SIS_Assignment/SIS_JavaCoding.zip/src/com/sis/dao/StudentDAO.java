package com.sis.dao;

import com.sis.entity.Student;
import java.util.List;
import com.sis.exception.InvalidStudentDataException;

public interface StudentDAO {
    void addStudent(Student student) throws InvalidStudentDataException;
    Student getStudentById(int studentId);
    List<Student> getAllStudents();
    void updateStudent(Student student)throws InvalidStudentDataException;
    void deleteStudent(int studentId);
}