package com.sis.dao;

import com.sis.entity.Student;
import com.sis.exception.InvalidStudentDataException;
import com.sis.exception.StudentNotFoundException;
import com.sis.util.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class StudentDAOImpl implements StudentDAO {
    private Connection connection;

    public StudentDAOImpl() {
        this.connection = DatabaseConnection.getConnection();
    }

    @Override
    public void addStudent(Student student) {
        try {
        	if (student.getFirstName() == null || student.getLastName() == null ||
        		    student.getDateOfBirth() == null || student.getEmail() == null ||
        		    student.getPhoneNumber() == null) {
        		    throw new InvalidStudentDataException("All student fields must be filled: firstName, lastName, dateOfBirth, email, phoneNumber.");
        		}

            String sql = "INSERT INTO students (first_name, last_name, date_of_birth, email, phone_number) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setString(1, student.getFirstName());
                stmt.setString(2, student.getLastName());
                stmt.setDate(3, new java.sql.Date(student.getDateOfBirth().getTime()));
                stmt.setString(4, student.getEmail());
                stmt.setString(5, student.getPhoneNumber());
                stmt.executeUpdate();
            }
        } catch (SQLException e) {
            System.err.println("Error adding student: " + e.getMessage());
        } catch (InvalidStudentDataException e) {
            System.err.println("Invalid student data: " + e.getMessage());
        }
    }

    @Override
    public Student getStudentById(int studentId) {
        String sql = "SELECT * FROM students WHERE student_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, studentId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Student(
                        rs.getInt("student_id"),
                        rs.getString("first_name"),
                        rs.getString("last_name"),
                        rs.getDate("date_of_birth"),
                        rs.getString("email"),
                        rs.getString("phone_number")
                );
            } else {
                throw new StudentNotFoundException("Student with ID " + studentId + " not found.");
            }
        } catch (SQLException e) {
            System.err.println("Error fetching student: " + e.getMessage());
        } catch (StudentNotFoundException e) {
            System.err.println("Student not found: " + e.getMessage());
        }
        return null;
    }

    @Override
    public List<Student> getAllStudents() {
        List<Student> students = new ArrayList<>();
        String sql = "SELECT * FROM students";
        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                students.add(new Student(
                        rs.getInt("student_id"),
                        rs.getString("first_name"),
                        rs.getString("last_name"),
                        rs.getDate("date_of_birth"),
                        rs.getString("email"),
                        rs.getString("phone_number")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching students: " + e.getMessage());
        }
        return students;
    }

    @Override
    public void updateStudent(Student student) {
        try {
        	if (student.getFirstName() == null || student.getLastName() == null ||
        		    student.getDateOfBirth() == null || student.getEmail() == null ||
        		    student.getPhoneNumber() == null) {
        		    throw new InvalidStudentDataException("All student fields must be filled: firstName, lastName, dateOfBirth, email, phoneNumber.");
        		}
            String sql = "UPDATE students SET first_name = ?, last_name = ?, date_of_birth = ?, email = ?, phone_number = ? WHERE student_id = ?";
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setString(1, student.getFirstName());
                stmt.setString(2, student.getLastName());
                stmt.setDate(3, new java.sql.Date(student.getDateOfBirth().getTime()));
                stmt.setString(4, student.getEmail());
                stmt.setString(5, student.getPhoneNumber());
                stmt.setInt(6, student.getStudentId());
                stmt.executeUpdate();
            }
        } catch (SQLException e) {
            System.err.println("Error updating student: " + e.getMessage());
        } catch (InvalidStudentDataException e) {
            System.err.println("Invalid student data: " + e.getMessage());
        }
    }

    @Override
    public void deleteStudent(int studentId) {
        String sql = "DELETE FROM students WHERE student_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, studentId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new StudentNotFoundException("No student found to delete with ID: " + studentId);
            }
        } catch (SQLException e) {
            System.err.println("Error deleting student: " + e.getMessage());
        } catch (StudentNotFoundException e) {
            System.err.println("Student not found: " + e.getMessage());
        }
    }
}
