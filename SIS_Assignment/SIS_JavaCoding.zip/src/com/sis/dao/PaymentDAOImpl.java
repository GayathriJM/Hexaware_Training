package com.sis.dao;

import com.sis.entity.Payment;
import com.sis.entity.Student;
import com.sis.exception.InvalidStudentDataException;
import com.sis.exception.PaymentValidationException;
import com.sis.exception.StudentNotFoundException;
import com.sis.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PaymentDAOImpl implements PaymentDAO {
    private Connection connection;

    public PaymentDAOImpl() {
        this.connection = DatabaseConnection.getConnection();
    }

    @Override
    public void addPayment(Payment payment) throws StudentNotFoundException, PaymentValidationException {
        if (payment.getAmount() <= 0 || payment.getPaymentDate() == null) {
            throw new PaymentValidationException("Invalid payment amount or date.");
        }

        if (!studentExists(payment.getStudent().getStudentId())) {
            throw new StudentNotFoundException("Student not found with ID: " + payment.getStudent().getStudentId());
        }

        String sql = "INSERT INTO payments (student_id, amount, payment_date) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, payment.getStudent().getStudentId());
            stmt.setDouble(2, payment.getAmount());
            stmt.setDate(3, new java.sql.Date(payment.getPaymentDate().getTime()));
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new PaymentValidationException("Error while adding payment: " + e.getMessage());
        }
    }

    @Override
    public Payment getPaymentById(int paymentId) throws PaymentValidationException {
        String sql = "SELECT * FROM payments WHERE payment_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, paymentId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                int studentId = rs.getInt("student_id");
                double amount = rs.getDouble("amount");
                Date paymentDate = rs.getDate("payment_date");

                Student student = new Student();
                student.setStudentId(studentId);

                return new Payment(paymentId, student, amount, paymentDate);
            } else {
                throw new PaymentValidationException("Payment not found with ID: " + paymentId);
            }
        } catch (SQLException e) {
            throw new PaymentValidationException("Error fetching payment: " + e.getMessage());
        }
    }

    @Override
    public List<Payment> getAllPayments() throws PaymentValidationException {
        List<Payment> payments = new ArrayList<>();
        String sql = "SELECT * FROM payments";
        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int paymentId = rs.getInt("payment_id");
                int studentId = rs.getInt("student_id");
                double amount = rs.getDouble("amount");
                Date paymentDate = rs.getDate("payment_date");

                Student student = new Student();
                student.setStudentId(studentId);

                Payment payment = new Payment(paymentId, student, amount, paymentDate);
                payments.add(payment);
            }
        } catch (SQLException e) {
            throw new PaymentValidationException("Error fetching payments: " + e.getMessage());
        }
        return payments;
    }

    @Override
    public void updatePayment(Payment payment) throws PaymentValidationException, StudentNotFoundException {
        if (payment.getAmount() <= 0 || payment.getPaymentDate() == null) {
            throw new PaymentValidationException("Invalid payment data.");
        }

        if (!studentExists(payment.getStudent().getStudentId())) {
            throw new StudentNotFoundException("Student not found with ID: " + payment.getStudent().getStudentId());
        }

        String sql = "UPDATE payments SET student_id = ?, amount = ?, payment_date = ? WHERE payment_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, payment.getStudent().getStudentId());
            stmt.setDouble(2, payment.getAmount());
            stmt.setDate(3, new java.sql.Date(payment.getPaymentDate().getTime()));
            stmt.setInt(4, payment.getPaymentId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new PaymentValidationException("Error updating payment: " + e.getMessage());
        }
    }

    @Override
    public void deletePayment(int paymentId) throws PaymentValidationException {
        String sql = "DELETE FROM payments WHERE payment_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, paymentId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new PaymentValidationException("Error deleting payment: " + e.getMessage());
        }
    }

    private boolean studentExists(int studentId) throws PaymentValidationException {
        String sql = "SELECT 1 FROM students WHERE student_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, studentId);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            throw new PaymentValidationException("Error checking student existence: " + e.getMessage());
        }
    }
}
