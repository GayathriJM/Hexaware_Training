package com.sis.dao;

import com.sis.entity.Course;
import com.sis.entity.Teacher;
import com.sis.exception.CourseNotFoundException;
import com.sis.exception.InvalidCourseDataException;
import com.sis.exception.TeacherNotFoundException;
import com.sis.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CourseDAOImpl implements CourseDAO {
    private Connection connection;

    public CourseDAOImpl() {
        this.connection = DatabaseConnection.getConnection();
    }

    private boolean teacherExists(int teacherId) throws SQLException {
        String sql = "SELECT 1 FROM teacher WHERE teacher_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, teacherId);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next();
            }
        }
    }

    @Override
    public void addCourse(Course course) throws InvalidCourseDataException, TeacherNotFoundException {
        if (course.getCourseName() == null || course.getCourseName().trim().isEmpty() ||
            course.getCourseCode() == null || course.getCourseCode().trim().isEmpty() ||
            course.getCredits() <= 0) {
            throw new InvalidCourseDataException("Course name, course code, and credits must be provided and valid.");
        }

        try {
            if (course.getTeacher() != null && !teacherExists(course.getTeacher().getTeacherId())) {
                throw new TeacherNotFoundException("Teacher with ID " + course.getTeacher().getTeacherId() + " not found.");
            }

            String sql = "INSERT INTO courses (course_name, course_code, credits, teacher_id) VALUES (?, ?, ?, ?)";
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setString(1, course.getCourseName());
                stmt.setString(2, course.getCourseCode());
                stmt.setInt(3, course.getCredits());
                stmt.setObject(4, course.getTeacher() != null ? course.getTeacher().getTeacherId() : null, Types.INTEGER);

                stmt.executeUpdate();
                System.out.println("Course added successfully!");
            }
        } catch (SQLException e) {
            System.err.println("Error adding course: " + e.getMessage());
        }
    }

    @Override
    public Course getCourseById(int courseId) throws CourseNotFoundException {
        String sql = "SELECT c.course_id, c.course_name, c.course_code, c.credits, t.teacher_id, t.first_name, t.last_name, t.email, t.expertise " +
                     "FROM courses c LEFT JOIN teacher t ON c.teacher_id = t.teacher_id WHERE c.course_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, courseId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Teacher teacher = null;
                if (rs.getObject("teacher_id") != null) {
                    teacher = new Teacher(
                        rs.getInt("teacher_id"),
                        rs.getString("first_name"),
                        rs.getString("last_name"),
                        rs.getString("email"),
                        rs.getString("expertise")
                    );
                }
                return new Course(
                    rs.getInt("course_id"),
                    rs.getString("course_name"),
                    rs.getString("course_code"),
                    rs.getInt("credits"),
                    teacher
                );
            } else {
                throw new CourseNotFoundException("Course with ID " + courseId + " not found.");
            }
        } catch (SQLException e) {
            System.err.println("Error fetching course: " + e.getMessage());
            return null;
        }
    }

    @Override
    public List<Course> getAllCourses() {
        List<Course> courses = new ArrayList<>();
        String sql = "SELECT course_id, course_name, course_code, credits, teacher_id FROM courses";
        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Teacher teacher = rs.getObject("teacher_id") != null ? new Teacher(rs.getInt("teacher_id")) : null;

                courses.add(new Course(
                    rs.getInt("course_id"),
                    rs.getString("course_name"),
                    rs.getString("course_code"),
                    rs.getInt("credits"),
                    teacher
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching courses: " + e.getMessage());
        }
        return courses;
    }

    @Override
    public void updateCourse(Course course) throws InvalidCourseDataException, CourseNotFoundException, TeacherNotFoundException {
        if (course.getCourseName() == null || course.getCourseName().trim().isEmpty() ||
            course.getCourseCode() == null || course.getCourseCode().trim().isEmpty() ||
            course.getCredits() <= 0) {
            throw new InvalidCourseDataException("Course name, course code, and credits must be provided and valid.");
        }

        try {
            if (course.getTeacher() != null && !teacherExists(course.getTeacher().getTeacherId())) {
                throw new TeacherNotFoundException("Teacher with ID " + course.getTeacher().getTeacherId() + " not found.");
            }

            String sql = "UPDATE courses SET course_name = ?, course_code = ?, credits = ?, teacher_id = ? WHERE course_id = ?";
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setString(1, course.getCourseName());
                stmt.setString(2, course.getCourseCode());
                stmt.setInt(3, course.getCredits());
                stmt.setObject(4, course.getTeacher() != null ? course.getTeacher().getTeacherId() : null, Types.INTEGER);
                stmt.setInt(5, course.getCourseId());

                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected == 0) {
                    throw new CourseNotFoundException("Course with ID " + course.getCourseId() + " not found.");
                }
            }
        } catch (SQLException e) {
            System.err.println("Error updating course: " + e.getMessage());
        }
    }

    @Override
    public void deleteCourse(int courseId) throws CourseNotFoundException {
        String sql = "DELETE FROM courses WHERE course_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, courseId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new CourseNotFoundException("Course with ID " + courseId + " not found.");
            }
        } catch (SQLException e) {
            System.err.println("Error deleting course: " + e.getMessage());
        }
    }
}
