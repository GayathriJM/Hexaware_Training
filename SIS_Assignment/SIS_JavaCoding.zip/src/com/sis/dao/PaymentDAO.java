package com.sis.dao;

import com.sis.entity.Payment;
import com.sis.exception.PaymentValidationException;
import com.sis.exception.StudentNotFoundException;

import java.util.List;

public interface PaymentDAO {
    void addPayment(Payment payment) throws StudentNotFoundException, PaymentValidationException;
    Payment getPaymentById(int paymentId) throws PaymentValidationException;
    List<Payment> getAllPayments() throws PaymentValidationException;
    void updatePayment(Payment payment) throws StudentNotFoundException, PaymentValidationException;
    void deletePayment(int paymentId) throws PaymentValidationException;
}
