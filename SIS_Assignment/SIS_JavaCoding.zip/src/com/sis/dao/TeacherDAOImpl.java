package com.sis.dao;

import com.sis.entity.Teacher;
import com.sis.exception.*;
import com.sis.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TeacherDAOImpl implements TeacherDAO {
    private Connection connection;

    public TeacherDAOImpl() {
        this.connection = DatabaseConnection.getConnection();
    }

    @Override
    public void addTeacher(Teacher teacher) throws InvalidTeacherDataException {
        String sql = "INSERT INTO teacher (first_name, last_name, email, expertise) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            if (teacher.getFirstName() == null || teacher.getLastName() == null || teacher.getEmail() == null) {
                throw new InvalidTeacherDataException("Teacher details are incomplete.");
            }

            stmt.setString(1, teacher.getFirstName());
            stmt.setString(2, teacher.getLastName());
            stmt.setString(3, teacher.getEmail());
            stmt.setString(4, teacher.getExpertise());
            stmt.executeUpdate();
        } catch (SQLIntegrityConstraintViolationException e) {
            throw new InvalidTeacherDataException("Teacher with this email already exists.");
        } catch (SQLException e) {
            throw new InvalidTeacherDataException("Error adding teacher: " + e.getMessage());
        }
    }

    @Override
    public Teacher getTeacherById(int teacherId) throws TeacherNotFoundException {
        String sql = "SELECT * FROM teacher WHERE teacher_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, teacherId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Teacher(
                    rs.getInt("teacher_id"),
                    rs.getString("first_name"),
                    rs.getString("last_name"),
                    rs.getString("email"),
                    rs.getString("expertise")
                );
            } else {
                throw new TeacherNotFoundException("Teacher with ID " + teacherId + " not found.");
            }
        } catch (SQLException e) {
            throw new TeacherNotFoundException("Error fetching teacher: " + e.getMessage());
        }
    }

    @Override
    public List<Teacher> getAllTeachers() {
        List<Teacher> teachers = new ArrayList<>();
        String sql = "SELECT * FROM teacher";
        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Teacher teacher = new Teacher(
                    rs.getInt("teacher_id"),
                    rs.getString("first_name"),
                    rs.getString("last_name"),
                    rs.getString("email"),
                    rs.getString("expertise")
                );
                teachers.add(teacher);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching teachers: " + e.getMessage());
        }
        return teachers;
    }

    @Override
    public void updateTeacher(Teacher teacher) throws InvalidTeacherDataException, TeacherNotFoundException {
        String sql = "UPDATE teacher SET first_name = ?, last_name = ?, email = ?, expertise = ? WHERE teacher_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, teacher.getFirstName());
            stmt.setString(2, teacher.getLastName());
            stmt.setString(3, teacher.getEmail());
            stmt.setString(4, teacher.getExpertise());
            stmt.setInt(5, teacher.getTeacherId());

            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated == 0) {
                throw new TeacherNotFoundException("Teacher with ID " + teacher.getTeacherId() + " not found.");
            }
        } catch (SQLException e) {
            throw new InvalidTeacherDataException("Error updating teacher: " + e.getMessage());
        }
    }

    @Override
    public void deleteTeacher(int teacherId) throws TeacherNotFoundException {
        String sql = "DELETE FROM teacher WHERE teacher_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, teacherId);
            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted == 0) {
                throw new TeacherNotFoundException("Teacher with ID " + teacherId + " not found.");
            }
        } catch (SQLException e) {
            throw new TeacherNotFoundException("Error deleting teacher: " + e.getMessage());
        }
    }
}
