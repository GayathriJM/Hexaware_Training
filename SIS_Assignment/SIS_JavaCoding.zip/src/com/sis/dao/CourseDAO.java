package com.sis.dao;

import com.sis.entity.Course;
import com.sis.exception.CourseNotFoundException;
import com.sis.exception.InvalidCourseDataException;
import com.sis.exception.TeacherNotFoundException;

import java.util.List;

public interface CourseDAO {
    void addCourse(Course course) throws InvalidCourseDataException, TeacherNotFoundException;
    Course getCourseById(int courseId) throws CourseNotFoundException;
    List<Course> getAllCourses();
    void updateCourse(Course course) throws InvalidCourseDataException, CourseNotFoundException, TeacherNotFoundException;
    void deleteCourse(int courseId) throws CourseNotFoundException;
}
