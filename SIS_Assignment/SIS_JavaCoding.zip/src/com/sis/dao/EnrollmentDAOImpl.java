package com.sis.dao;

import com.sis.entity.Course;
import com.sis.entity.Enrollment;
import com.sis.entity.Student;
import com.sis.util.DatabaseConnection;
import com.sis.exception.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EnrollmentDAOImpl implements EnrollmentDAO {
    private Connection connection;

    public EnrollmentDAOImpl() {
        this.connection = DatabaseConnection.getConnection();
    }

    @Override
    public void addEnrollment(Enrollment enrollment)
            throws InvalidEnrollmentDataException, DuplicateEnrollmentException,
                   StudentNotFoundException, CourseNotFoundException {

        if (enrollment.getStudent() == null || enrollment.getCourse() == null || enrollment.getEnrollmentDate() == null) {
            throw new InvalidEnrollmentDataException("Enrollment data is incomplete.");
        }

        int studentId = enrollment.getStudent().getStudentId();
        int courseId = enrollment.getCourse().getCourseId();

        if (!isStudentExists(studentId)) {
            throw new StudentNotFoundException("Student not found with ID: " + studentId);
        }

        if (!isCourseExists(courseId)) {
            throw new CourseNotFoundException("Course not found with ID: " + courseId);
        }

        if (isDuplicateEnrollment(studentId, courseId)) {
            throw new DuplicateEnrollmentException("Student is already enrolled in this course.");
        }

        String sql = "INSERT INTO enrollments (student_id, course_id, enrollment_date) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, studentId);
            stmt.setInt(2, courseId);
            stmt.setDate(3, new java.sql.Date(enrollment.getEnrollmentDate().getTime()));
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error adding enrollment: " + e.getMessage());
        }
    }

    @Override
    public Enrollment getEnrollmentById(int enrollmentId) throws InvalidEnrollmentDataException {
        String sql = "SELECT * FROM enrollments WHERE enrollment_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, enrollmentId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Student student = new Student();
                student.setStudentId(rs.getInt("student_id"));

                Course course = new Course();
                course.setCourseId(rs.getInt("course_id"));

                return new Enrollment(
                    rs.getInt("enrollment_id"),
                    student,
                    course,
                    rs.getDate("enrollment_date")
                );
            } else {
                throw new InvalidEnrollmentDataException("Invalid enrollment ID: " + enrollmentId);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching enrollment: " + e.getMessage());
            return null;
        }
    }

    @Override
    public List<Enrollment> getAllEnrollments() {
        List<Enrollment> enrollments = new ArrayList<>();
        String sql = "SELECT * FROM enrollments";
        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Student student = new Student();
                student.setStudentId(rs.getInt("student_id"));

                Course course = new Course();
                course.setCourseId(rs.getInt("course_id"));

                Enrollment enrollment = new Enrollment(
                        rs.getInt("enrollment_id"),
                        student,
                        course,
                        rs.getDate("enrollment_date")
                );
                enrollments.add(enrollment);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching enrollments: " + e.getMessage());
        }
        return enrollments;
    }

    @Override
    public void updateEnrollment(Enrollment enrollment) throws InvalidEnrollmentDataException {
        if (!isEnrollmentExists(enrollment.getEnrollmentId())) {
            throw new InvalidEnrollmentDataException("Invalid enrollment ID: " + enrollment.getEnrollmentId());
        }

        String sql = "UPDATE enrollments SET student_id = ?, course_id = ?, enrollment_date = ? WHERE enrollment_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, enrollment.getStudent().getStudentId());
            stmt.setInt(2, enrollment.getCourse().getCourseId());
            stmt.setDate(3, new java.sql.Date(enrollment.getEnrollmentDate().getTime()));
            stmt.setInt(4, enrollment.getEnrollmentId());
            stmt.executeUpdate();
            System.out.println("Enrollment updated successfully!");
        } catch (SQLException e) {
            System.err.println("Error updating enrollment: " + e.getMessage());
        }
    }

    @Override
    public void deleteEnrollment(int enrollmentId) throws InvalidEnrollmentDataException {
        if (!isEnrollmentExists(enrollmentId)) {
            throw new InvalidEnrollmentDataException("Invalid enrollment ID: " + enrollmentId);
        }

        String sql = "DELETE FROM enrollments WHERE enrollment_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, enrollmentId);
            stmt.executeUpdate();
            System.out.println("Enrollment deleted successfully!");
        } catch (SQLException e) {
            System.err.println("Error deleting enrollment: " + e.getMessage());
        }
    }

    @Override
    public List<Enrollment> getEnrollmentsByStudentId(int studentId) {
        List<Enrollment> enrollments = new ArrayList<>();
        String sql = "SELECT e.enrollment_id, e.enrollment_date, c.course_id, c.course_name, c.course_code, c.credits " +
                     "FROM enrollments e " +
                     "JOIN courses c ON e.course_id = c.course_id " +
                     "WHERE e.student_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, studentId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Student student = new Student();
                student.setStudentId(studentId);

                Course course = new Course();
                course.setCourseId(rs.getInt("course_id"));
                course.setCourseName(rs.getString("course_name"));
                course.setCourseCode(rs.getString("course_code"));
                course.setCredits(rs.getInt("credits"));

                Enrollment enrollment = new Enrollment(
                    rs.getInt("enrollment_id"),
                    student,
                    course,
                    rs.getDate("enrollment_date")
                );
                enrollments.add(enrollment);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching enrollments by student ID: " + e.getMessage());
        }
        return enrollments;
    }

    @Override
    public List<Enrollment> getEnrollmentsByCourseId(int courseId) {
        List<Enrollment> enrollments = new ArrayList<>();
        String sql = "SELECT e.enrollment_id, e.enrollment_date, s.student_id, s.first_name, s.last_name, s.email, s.phone_number " +
                     "FROM enrollments e " +
                     "JOIN students s ON e.student_id = s.student_id " +
                     "WHERE e.course_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, courseId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Student student = new Student();
                student.setStudentId(rs.getInt("student_id"));
                student.setFirstName(rs.getString("first_name"));
                student.setLastName(rs.getString("last_name"));
                student.setEmail(rs.getString("email"));
                student.setPhoneNumber(rs.getString("phone_number"));

                Course course = new Course();
                course.setCourseId(courseId);

                Enrollment enrollment = new Enrollment(
                    rs.getInt("enrollment_id"),
                    student,
                    course,
                    rs.getDate("enrollment_date")
                );
                enrollments.add(enrollment);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching enrollments by course ID: " + e.getMessage());
        }
        return enrollments;
    }

    // Helper Methods
    private boolean isStudentExists(int studentId) {
        String sql = "SELECT student_id FROM students WHERE student_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, studentId);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            return false;
        }
    }

    private boolean isCourseExists(int courseId) {
        String sql = "SELECT course_id FROM courses WHERE course_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, courseId);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            return false;
        }
    }

    private boolean isDuplicateEnrollment(int studentId, int courseId) {
        String sql = "SELECT enrollment_id FROM enrollments WHERE student_id = ? AND course_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, studentId);
            stmt.setInt(2, courseId);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            return false;
        }
    }

    private boolean isEnrollmentExists(int enrollmentId) {
        String sql = "SELECT enrollment_id FROM enrollments WHERE enrollment_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, enrollmentId);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            return false;
        }
    }
}
