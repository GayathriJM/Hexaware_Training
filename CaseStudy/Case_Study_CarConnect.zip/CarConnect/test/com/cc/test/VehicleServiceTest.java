package com.cc.test;

import com.cc.entity.Vehicle;
import com.cc.service.VehicleServiceImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class VehicleServiceTest {

    private VehicleServiceImpl vehicleService;

    @BeforeEach
    public void setUp() {
        vehicleService = new VehicleServiceImpl();
    }

    @Test
    public void testAddNewVehicle() {
        Vehicle vehicle = new Vehicle();
        vehicle.setModel("Benz");
        vehicle.setMake("car");
        vehicle.setYear(2023);
        vehicle.setColor("Blue");
        vehicle.setRegistrationNumber("TN78SWIFT22");
        vehicle.setDailyRate(1500.00);
        vehicle.setAvailability(true);

        boolean added = vehicleService.addVehicle(vehicle);
        assertTrue(added, "Vehicle should be added successfully");
    }

    @Test
    public void testUpdateVehicleDetails() {
        Vehicle vehicle = vehicleService.getVehicleById(2); 
        assertNotNull(vehicle, "Vehicle should exist");

        vehicle.setColor("Black");
        boolean updated = vehicleService.updateVehicle(vehicle);
        assertTrue(updated, "Vehicle should be updated");

        Vehicle updatedVehicle = vehicleService.getVehicleById(2);
        assertEquals("Black", updatedVehicle.getColor(), "Color should be updated");
    }

    @Test
    public void testGetAvailableVehicles() {
        List<Vehicle> availableVehicles = vehicleService.getAvailableVehicles();
        assertNotNull(availableVehicles, "Available vehicle list should not be null");
        assertTrue(availableVehicles.size() > 0, "Should return at least one available vehicle");

        System.out.println("---- Available Vehicles ----");
        for (Vehicle v : availableVehicles) {
            System.out.println("ID: " + v.getVehicleID() + " | " + v.getMake() + " " + v.getModel());
        }
    }

    @Test
    public void testGetAllVehicles() {

        List<Vehicle> allVehicles = vehicleService.getAllVehicles(); 
        assertNotNull(allVehicles, "Vehicle list should not be null");
        assertTrue(allVehicles.size() > 0, "There should be at least one vehicle");
        System.out.println();
        System.out.println("---- All Vehicles (Simulated) ----");
        for (Vehicle v : allVehicles) {
            System.out.println("ID: " + v.getVehicleID() + " | Reg#: " + v.getRegistrationNumber());
        }
    }
}