package com.cc.test;

import com.cc.entity.Customer;
import com.cc.service.CustomerServiceImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


import static org.junit.jupiter.api.Assertions.*;

public class CustomerServiceTest {

    private CustomerServiceImpl customerService;

    @BeforeEach
    public void setUp() {
        customerService = new CustomerServiceImpl();
    }

    @Test
    public void testInvalidAuthentication() {
        Customer invalid = customerService.getCustomerByUsername("nonexistentuser123");
        assertNull(invalid, "Customer should not exist with invalid username");
    }

    @Test
    public void testUpdateCustomerInformation() {
        Customer customer = customerService.getCustomerById(1); 
        assertNotNull(customer, "Customer should exist");

        String newPhone = "9999999999";
        customer.setPhoneNumber(newPhone);
        boolean updated = customerService.updateCustomer(customer);
        assertTrue(updated, "Customer should be updated");

        Customer updatedCustomer = customerService.getCustomerById(1);
        assertEquals(newPhone, updatedCustomer.getPhoneNumber(), "Phone number should be updated");
    }

}