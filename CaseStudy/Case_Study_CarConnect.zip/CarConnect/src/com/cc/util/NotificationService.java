package com.cc.util;

import com.cc.entity.Reservation;

public class NotificationService {

    public void sendReservationConfirmation(String customerEmail, String customerPhone, Reservation reservation) {
        System.out.println("\n[EMAIL SENT TO: " + customerEmail + "]");
        System.out.println("Subject: Reservation Confirmation");
        System.out.println("Body: Hello, your reservation (ID: " + reservation.getReservationID() + 
            ") for vehicle ID " + reservation.getVehicleID() + " from " +
            reservation.getStartDate() + " to " + reservation.getEndDate() + " has been confirmed.");

        System.out.println("\n[SMS SENT TO: " + customerPhone + "]");
        System.out.println("Message: Your reservation (ID: " + reservation.getReservationID() +
            ") is confirmed. Thank you for using CarConnect.\n");
    }

    public void sendReminder(String customerEmail, String customerPhone, Reservation reservation) {
        System.out.println("\n[REMINDER]");
        System.out.println("To: " + customerEmail + " / " + customerPhone);
        System.out.println("Reminder: Your reservation (ID: " + reservation.getReservationID() +
            ") starts on " + reservation.getStartDate() + ". Please be ready!");
    }
}
