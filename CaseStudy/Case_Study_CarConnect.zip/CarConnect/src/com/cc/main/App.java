package com.cc.main;

import com.cc.dao.ICustomerService;
import com.cc.entity.Customer;
import com.cc.dao.IAddressService;
import com.cc.entity.Address;
import com.cc.enums.AddressType;
import com.cc.dao.IVehicleService;
import com.cc.entity.Vehicle;
import com.cc.dao.IReservationService;
import com.cc.entity.Reservation;
import com.cc.enums.ReservationStatus;
import com.cc.exception.AddressNotFoundException;
import com.cc.exception.AdminNotFoundException;
import com.cc.exception.AuthenticationException;
import com.cc.exception.InvalidInputException;
import com.cc.exception.ReservationException;
import com.cc.exception.RoleNotFoundException;
import com.cc.exception.VehicleNotFoundException;
import com.cc.service.AddressServiceImpl;
import com.cc.service.AdminServiceImpl;
import com.cc.service.CustomerServiceImpl;
import com.cc.service.ReportServiceImpl;
import com.cc.service.ReservationServiceImpl;
import com.cc.service.RoleServiceImpl;
import com.cc.service.VehicleServiceImpl;
import com.cc.dao.IRoleService;
import com.cc.entity.Role;
import com.cc.dao.IAdminService;
import com.cc.entity.Admin;
import com.cc.dao.IReportService;
import com.cc.util.DBConnUtil;


import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

public class App {
    public static void main(String[] args) {
    	DBConnUtil.getConnection("resources/db.properties");
        Scanner scanner = new Scanner(System.in);
        ICustomerService customerService = new CustomerServiceImpl();
        IAddressService addressService = new AddressServiceImpl();
        IVehicleService vehicleService = new VehicleServiceImpl();
        IReservationService reservationService = new ReservationServiceImpl();
        IRoleService roleService = new RoleServiceImpl();
        IAdminService adminService = new AdminServiceImpl();
        IReportService reportService = new ReportServiceImpl();


        while (true) {
            System.out.println("\n========= CarConnect System =========");
            System.out.println("1. Customer Management");
            System.out.println("2. Address Management");
            System.out.println("3. Vehicle Management");
            System.out.println("4. Reservation Management");
            System.out.println("5. Role Management");
            System.out.println("6. Admin Management");
            System.out.println("7. Reports");
            System.out.println("8. Exit");
            System.out.print("Enter your choice: ");
            int mainChoice = scanner.nextInt();
            scanner.nextLine(); 

            switch (mainChoice) {
                case 1:
                    customerManagementMenu(scanner, customerService);
                    break;
                case 2:
                    addressManagementMenu(scanner, addressService);
                    break;
                case 3:
                    vehicleManagementMenu(scanner, vehicleService);
                    break;
                case 4:
                    reservationManagementMenu(scanner, reservationService,customerService,vehicleService);
                    break;
                case 5:
                    roleManagementMenu(scanner, roleService);
                    break;
                case 6:
                    adminManagementMenu(scanner, adminService);
                    break;
                case 7:
                    reportMenu(scanner, reportService);
                    break;
                case 8:
                    System.out.println("Exiting CarConnect");
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice! Please try again");
            }
        }
    }

    private static void customerManagementMenu(Scanner scanner, ICustomerService customerService) {
        while (true) {
            System.out.println("\n----- Customer Management -----");
            System.out.println("1. Register Customer");
            System.out.println("2. View All Customers");
            System.out.println("3. Get Customer by ID");
            System.out.println("4. Get Customer by Username");
            System.out.println("5. Update Customer");
            System.out.println("6. Delete Customer");
            System.out.println("7. Return to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1: // Register
                	try {
                    Customer newCustomer = new Customer();
                    System.out.print("First Name: ");
                    newCustomer.setFirstName(scanner.nextLine());
                    System.out.print("Last Name: ");
                    newCustomer.setLastName(scanner.nextLine());
                    System.out.print("Email: ");
                    newCustomer.setEmail(scanner.nextLine());
                    System.out.print("Phone Number: ");
                    newCustomer.setPhoneNumber(scanner.nextLine());
                    System.out.print("Username: ");
                    newCustomer.setUsername(scanner.nextLine());
                    System.out.print("Password: ");
                    String password = scanner.nextLine();
                    newCustomer.setPasswordHash(password);
                    newCustomer.setRegistrationDate(LocalDateTime.now());

                    boolean isRegistered = customerService.registerCustomer(newCustomer);
                    System.out.println(isRegistered ? "Customer registered successfully!" : "Registration failed.");
                	} catch (InvalidInputException e) {
                        System.err.println("Input Error: " + e.getMessage());
                    } catch (Exception e) {
                        System.err.println("Unexpected error: " + e.getMessage());
                    }
                    break;

                case 2: // View All
                    List<Customer> customers = customerService.getAllCustomers();
                    if (customers.isEmpty()) {
                        System.out.println("No customers found.");
                    } else {
                        System.out.println("Customer List:");
                        for (Customer c : customers) {
                        	c.display();
                            System.out.println("-----------------------------------");
                        }
                    }
                    break;

                case 3: // Get by ID
                    System.out.print("Enter Customer ID: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();
                    Customer customerById = customerService.getCustomerById(id);
                    if (customerById != null) {
                    	customerById.display();
                    } else {
                        System.out.println("Customer not found.");
                    }
                    break;

                case 4: // Get by Username
                    System.out.print("Enter Username: ");
                    String uname = scanner.nextLine();
                    try {
                    Customer customerByUsername = customerService.getCustomerByUsername(uname);
                    if (customerByUsername != null) {
                    	customerByUsername.display();
                    } else {
                        System.out.println("Customer not found.");
                    }
                    } catch (AuthenticationException e) {
                        System.err.println("Authentication Error: " + e.getMessage());
                    }
                    break;

                case 5: // Update
                    System.out.print("Enter Customer ID to update: ");
                    int updateId = scanner.nextInt();
                    scanner.nextLine();
                    Customer existing = customerService.getCustomerById(updateId);
                    if (existing != null) {
                        System.out.println("Updating Customer: " + existing.getUsername());
                        System.out.print("New First Name [" + existing.getFirstName() + "]: ");
                        String newFirstName = scanner.nextLine();
                        if (!newFirstName.trim().isEmpty()) {
                            existing.setFirstName(newFirstName);
                        }

                        System.out.print("New Last Name [" + existing.getLastName() + "]: ");
                        String newLastName = scanner.nextLine();
                        if (!newLastName.trim().isEmpty()) {
                            existing.setLastName(newLastName);
                        }

                        System.out.print("New Email [" + existing.getEmail() + "]: ");
                        String newEmail = scanner.nextLine();
                        if (!newEmail.trim().isEmpty()) {
                            existing.setEmail(newEmail);
                        }

                        System.out.print("New Phone [" + existing.getPhoneNumber() + "]: ");
                        String newPhone = scanner.nextLine();
                        if (!newPhone.trim().isEmpty()) {
                            existing.setPhoneNumber(newPhone);
                        }

                        System.out.print("New Username [" + existing.getUsername() + "]: ");
                        String newUsername = scanner.nextLine();
                        if (!newUsername.trim().isEmpty()) {
                            existing.setUsername(newUsername);
                        }

                        System.out.print("New Password [Hidden]: ");
                        String newPassword = scanner.nextLine();
                        if (!newPassword.trim().isEmpty()) {
                            existing.setPasswordHash(newPassword);
                        }

                        boolean updated = customerService.updateCustomer(existing);
                        System.out.println(updated ? "Updated successfully!" : "Update failed.");
                    } else {
                        System.out.println("Customer not found.");
                    }
                    break;

                case 6: // Delete
                    System.out.print("Enter Customer ID to delete: ");
                    int deleteId = scanner.nextInt();
                    boolean deleted = customerService.deleteCustomer(deleteId);
                    System.out.println(deleted ? "Customer deleted successfully!" : "Deletion failed.");
                    break;

                case 7:
                    return;

                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
    private static void addressManagementMenu(Scanner scanner, IAddressService addressService) {
        while (true) {
            System.out.println("\n----- Address Management -----");
            System.out.println("1. Add Address");
            System.out.println("2. Get Address by ID");
            System.out.println("3. Get Addresses by Customer ID");
            System.out.println("4. Update Address");
            System.out.println("5. Delete Address");
            System.out.println("6. Return to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                	try {
                    Address newAddress = new Address();
                    System.out.print("Customer ID: ");
                    newAddress.setCustomerID(scanner.nextInt());
                    scanner.nextLine();
                    System.out.print("Street: ");
                    newAddress.setStreet(scanner.nextLine());
                    System.out.print("City: ");
                    newAddress.setCity(scanner.nextLine());
                    System.out.print("State: ");
                    newAddress.setState(scanner.nextLine());
                    System.out.print("ZIP: ");
                    newAddress.setZipCode(scanner.nextLine());
                    System.out.print("Address Type (Home/Office/Other): ");
                    newAddress.setAddressType(AddressType.valueOf(scanner.nextLine()));
                    boolean added = addressService.addAddress(newAddress);
                    System.out.println(added ? "Address added." : "Failed to add.");
                	} catch (InvalidInputException e) {
                        System.err.println("Invalid input: " + e.getMessage());
                    } catch (IllegalArgumentException e) {
                        System.err.println("Invalid address type.");
                    }
                    break;

                case 2:
                	try {
                    System.out.print("Enter Address ID: ");
                    Address addr = addressService.getAddressById(scanner.nextInt());
                    addr.display();
                	} catch (AddressNotFoundException e) {
                        System.err.println(e.getMessage());
                    }
                    break;

                case 3:
                    System.out.print("Enter Customer ID: ");
                    List<Address> addressList = addressService.getAddressesByCustomerId(scanner.nextInt());
                    if (addressList.isEmpty()) {
                        System.out.println("No addresses found for this customer.");
                    } else {
                        for (Address a : addressList) {
                        	a.display();
                            System.out.println("-----------------------------------");
                        }
                    }
                    break;

                case 4:
                	try {
                    System.out.print("Enter Address ID to update: ");
                    int idToUpdate = scanner.nextInt();
                    scanner.nextLine();
                    Address addrToUpdate = addressService.getAddressById(idToUpdate);
                    	System.out.print("New Street [" + addrToUpdate.getStreet() + "]: ");
                        String newStreet = scanner.nextLine();
                        if (!newStreet.trim().isEmpty()) {
                            addrToUpdate.setStreet(newStreet);
                        }

                        System.out.print("New City [" + addrToUpdate.getCity() + "]: ");
                        String newCity = scanner.nextLine();
                        if (!newCity.trim().isEmpty()) {
                            addrToUpdate.setCity(newCity);
                        }

                        System.out.print("New State [" + addrToUpdate.getState() + "]: ");
                        String newState = scanner.nextLine();
                        if (!newState.trim().isEmpty()) {
                            addrToUpdate.setState(newState);
                        }

                        System.out.print("New ZIP [" + addrToUpdate.getZipCode() + "]: ");
                        String newZip = scanner.nextLine();
                        if (!newZip.trim().isEmpty()) {
                            addrToUpdate.setZipCode(newZip);
                        }

                        System.out.print("New Address Type [" + addrToUpdate.getAddressType() + "] (Home/Office/Other): ");
                        String newAddrTypeStr = scanner.nextLine();
                        if (!newAddrTypeStr.trim().isEmpty()) {
                            addrToUpdate.setAddressType(AddressType.valueOf(newAddrTypeStr));
                        }
                        boolean updated = addressService.updateAddress(addrToUpdate);
                        System.out.println(updated ? "Address updated." : "Update failed.");
                    } catch (AddressNotFoundException | InvalidInputException e) {
                        System.err.println(e.getMessage());
                    }
                    break;

                case 5:
                	try {
                    System.out.print("Enter Address ID to delete: ");
                    boolean deleted = addressService.deleteAddress(scanner.nextInt());
                    System.out.println(deleted ? "Deleted." : "Deletion failed.");
                	} catch (AddressNotFoundException e) {
                        System.err.println(e.getMessage());
                    }
                    break;

                case 6:
                    return;

                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
    private static void vehicleManagementMenu(Scanner scanner, IVehicleService vehicleService) {
        while (true) {
            System.out.println("\n----- Vehicle Management -----");
            System.out.println("1. Add Vehicle");
            System.out.println("2. View Available Vehicles");
            System.out.println("3. View All Vehicles"); 
            System.out.println("4. Get Vehicle by ID");
            System.out.println("5. Update Vehicle");
            System.out.println("6. Remove Vehicle");
            System.out.println("7. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    Vehicle newVehicle = new Vehicle();
                    System.out.print("Enter Model: ");
                    newVehicle.setModel(scanner.nextLine());
                    System.out.print("Enter Make: ");
                    newVehicle.setMake(scanner.nextLine());
                    System.out.print("Enter Year: ");
                    newVehicle.setYear(scanner.nextInt());
                    scanner.nextLine();
                    System.out.print("Enter Color: ");
                    newVehicle.setColor(scanner.nextLine());
                    System.out.print("Enter Registration Number: ");
                    newVehicle.setRegistrationNumber(scanner.nextLine());
                    System.out.print("Enter Daily Rate: ");
                    newVehicle.setDailyRate(scanner.nextDouble());
                    System.out.print("Is Available (true/false): ");
                    newVehicle.setAvailability(scanner.nextBoolean());

                    try {
                        boolean added = vehicleService.addVehicle(newVehicle);
                        System.out.println(added ? "Vehicle added successfully." : "Failed to add vehicle.");
                    } catch (InvalidInputException e) {
                        System.err.println("Input Error: " + e.getMessage());
                    }
                    break;

                case 2:
                    List<Vehicle> availableVehicles = vehicleService.getAvailableVehicles();
                    if (availableVehicles.isEmpty()) {
                        System.out.println("No available vehicles found.");
                    } else {
                        for (Vehicle v : availableVehicles) {
                        	System.out.printf("%d - %s %s (%d, %s) - ₹%.2f%n",
                        		    v.getVehicleID(), v.getMake(), v.getModel(), v.getYear(),
                        		    v.getColor(), v.getDailyRate());
                        }
                    }
                    break;
                    
                case 3:
                    List<Vehicle> allVehicles = vehicleService.getAllVehicles();
                    if (allVehicles.isEmpty()) {
                        System.out.println("No vehicles found.");
                    } else {
                        System.out.println("\n---- All Vehicles ----");
                        for (Vehicle v : allVehicles) {
                            System.out.printf("%d - %s %s (%d, %s) - ₹%.2f - Available: %b%n",
                                    v.getVehicleID(), v.getMake(), v.getModel(), v.getYear(),
                                    v.getColor(), v.getDailyRate(), v.isAvailability());
                        }
                    }
                    break;

                case 4:
                    System.out.print("Enter Vehicle ID: ");
                    int searchId = scanner.nextInt();
                    try {
                    Vehicle foundVehicle = vehicleService.getVehicleById(searchId);
                    
                        System.out.println("Vehicle ID: " + foundVehicle.getVehicleID());
                        System.out.println("Model: " + foundVehicle.getModel());
                        System.out.println("Make: " + foundVehicle.getMake());
                        System.out.println("Year: " + foundVehicle.getYear());
                        System.out.println("Color: " + foundVehicle.getColor());
                        System.out.println("Registration No: " + foundVehicle.getRegistrationNumber());
                        System.out.println("Daily Rate: " + foundVehicle.getDailyRate());
                        System.out.println("Available: " + foundVehicle.isAvailability());
                    } catch (VehicleNotFoundException e) {
                        System.err.println(e.getMessage());
                    }
                    break;

                case 5:
                    System.out.print("Enter Vehicle ID to update: ");
                    int updateId = scanner.nextInt();
                    scanner.nextLine(); 
                    try {
                    Vehicle vehicleToUpdate = vehicleService.getVehicleById(updateId);
                   
                    	System.out.print("Enter new Model [" + vehicleToUpdate.getModel() + "]: ");
                        String model = scanner.nextLine();
                        if (!model.trim().isEmpty()) vehicleToUpdate.setModel(model);

                        System.out.print("Enter new Make [" + vehicleToUpdate.getMake() + "]: ");
                        String make = scanner.nextLine();
                        if (!make.trim().isEmpty()) vehicleToUpdate.setMake(make);

                        System.out.print("Enter new Year [" + vehicleToUpdate.getYear() + "]: ");
                        String yearStr = scanner.nextLine();
                        if (!yearStr.trim().isEmpty()) vehicleToUpdate.setYear(Integer.parseInt(yearStr));

                        System.out.print("Enter new Color [" + vehicleToUpdate.getColor() + "]: ");
                        String color = scanner.nextLine();
                        if (!color.trim().isEmpty()) vehicleToUpdate.setColor(color);

                        System.out.print("Enter new Registration Number [" + vehicleToUpdate.getRegistrationNumber() + "]: ");
                        String regNum = scanner.nextLine();
                        if (!regNum.trim().isEmpty()) vehicleToUpdate.setRegistrationNumber(regNum);

                        System.out.print("Enter new Daily Rate [" + vehicleToUpdate.getDailyRate() + "]: ");
                        String rateStr = scanner.nextLine();
                        if (!rateStr.trim().isEmpty()) vehicleToUpdate.setDailyRate(Double.parseDouble(rateStr));

                        System.out.print("Is Available (true/false) [" + vehicleToUpdate.isAvailability() + "]: ");
                        String availStr = scanner.nextLine();
                        if (!availStr.trim().isEmpty()) vehicleToUpdate.setAvailability(Boolean.parseBoolean(availStr));

                        boolean updated = vehicleService.updateVehicle(vehicleToUpdate);
                        System.out.println(updated ? "Vehicle updated successfully." : "Failed to update.");
                        }
                    catch (VehicleNotFoundException | InvalidInputException e) {
                        System.err.println(e.getMessage());
                    }
                    break;

                case 6:
                	 System.out.print("Enter Vehicle ID to remove: ");
                     int removeId = scanner.nextInt();
                     try {
                         boolean removed = vehicleService.removeVehicle(removeId);
                         System.out.println(removed ? "Vehicle removed successfully." : "Failed to remove.");
                     } catch (VehicleNotFoundException e) {
                         System.err.println(e.getMessage());
                     }
                     break;

                case 7:
                    return;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
    private static void reservationManagementMenu(Scanner scanner, IReservationService reservationService, ICustomerService customerService,
            IVehicleService vehicleService) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        while (true) {
            System.out.println("\n----- Reservation Management -----");
            System.out.println("1. Create Reservation");
            System.out.println("2. View Reservation by ID");
            System.out.println("3. View Reservations by Customer ID");
            System.out.println("4. Update Reservation");
            System.out.println("5. Cancel Reservation");
            System.out.println("6. Send Reminder for a Reservation"); 
            System.out.println("7. Return to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    Reservation newReservation = new Reservation();
                    System.out.print("Customer ID: ");
                    newReservation.setCustomerID(scanner.nextInt());
                    System.out.print("Vehicle ID: ");
                    newReservation.setVehicleID(scanner.nextInt());
                    scanner.nextLine();
                    System.out.print("Start Date (yyyy-MM-dd HH:mm:ss): ");
                    newReservation.setStartDate(LocalDateTime.parse(scanner.nextLine(), formatter));
                    System.out.print("End Date (yyyy-MM-dd HH:mm:ss): ");
                    newReservation.setEndDate(LocalDateTime.parse(scanner.nextLine(), formatter));
                    System.out.print("Total Cost: ");
                    newReservation.setTotalCost(scanner.nextDouble());
                    scanner.nextLine();
                    System.out.print("Status (Pending/Confirmed/Completed/Cancelled): ");
                    newReservation.setStatus(ReservationStatus.valueOf(scanner.nextLine()));
                    if (customerService.getCustomerById(newReservation.getCustomerID()) == null) {
                        System.out.println("Customer ID does not exist.");
                        break;
                    }

                    if (vehicleService.getVehicleById(newReservation.getVehicleID()) == null) {
                        System.out.println("Vehicle ID does not exist.");
                        break;
                    }

                    try {
                    boolean created = reservationService.createReservation(newReservation);
                    System.out.println(created ? "Reservation created." : "Failed to create.");
                    } catch (InvalidInputException | ReservationException e) {
                        System.err.println(e.getMessage());
                    }
                    break;

                case 2:
                    System.out.print("Enter Reservation ID: ");
                    try {
                    Reservation res = reservationService.getReservationById(scanner.nextInt());
                    if (res != null) {
                    	res.display();
                    } else {
                        System.out.println("Reservation not found.");
                    }
                    } catch (ReservationException e) {
                        System.err.println(e.getMessage());
                    }
                    break;

                case 3:
                    System.out.print("Enter Customer ID: ");
                    List<Reservation> reservations = reservationService.getReservationsByCustomerId(scanner.nextInt());
                    if (reservations.isEmpty()) {
                        System.out.println("No reservations found for this customer.");
                    } else {
                        for (Reservation r : reservations) {
                        	r.display();
                            System.out.println("----------------------------------");
                        }
                    }
                    break;

                case 4:
                    System.out.print("Enter Reservation ID to update: ");
                    int updateId = scanner.nextInt();
                    scanner.nextLine();
                    try {
                    Reservation toUpdate = reservationService.getReservationById(updateId);
                    if (toUpdate != null) {
                        System.out.print("New Start Date [" + toUpdate.getStartDate() + "]: ");
                        String start = scanner.nextLine();
                        if (!start.trim().isEmpty()) toUpdate.setStartDate(LocalDateTime.parse(start, formatter));

                        System.out.print("New End Date [" + toUpdate.getEndDate() + "]: ");
                        String end = scanner.nextLine();
                        if (!end.trim().isEmpty()) toUpdate.setEndDate(LocalDateTime.parse(end, formatter));

                        System.out.print("New Total Cost [" + toUpdate.getTotalCost() + "]: ");
                        String cost = scanner.nextLine();
                        if (!cost.trim().isEmpty()) toUpdate.setTotalCost(Double.parseDouble(cost));

                        System.out.print("New Status [" + toUpdate.getStatus() + "]: ");
                        String status = scanner.nextLine();
                        if (!status.trim().isEmpty()) toUpdate.setStatus(ReservationStatus.valueOf(status));

                        boolean updated = reservationService.updateReservation(toUpdate);
                        System.out.println(updated ? "Reservation updated." : "Update failed.");
                    } else {
                        System.out.println("Reservation not found.");
                    }
                    } catch (InvalidInputException | ReservationException e) {
                        System.err.println(e.getMessage());
                    }
                    break;

                case 5:
                    System.out.print("Enter Reservation ID to cancel: ");
                    try {
                    boolean cancelled = reservationService.cancelReservation(scanner.nextInt());
                    System.out.println(cancelled ? "Reservation cancelled." : "Failed to cancel.");
                    } catch (ReservationException e) {
                        System.err.println(e.getMessage());
                    }
                    break;

                case 6:
                    System.out.print("Enter Reservation ID to send reminder: ");
                    int remId = scanner.nextInt();
                    scanner.nextLine();
                    ((ReservationServiceImpl) reservationService).sendReminderForReservation(remId);
                    break;
                    
                case 7:
                    return;

                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }
    private static void roleManagementMenu(Scanner scanner, IRoleService roleService) {
        while (true) {
            System.out.println("\n----- Role Management -----");
            System.out.println("1. Add Role");
            System.out.println("2. View All Roles");
            System.out.println("3. Get Role by ID");
            System.out.println("4. Get Role by Name");
            System.out.println("5. Update Role");
            System.out.println("6. Delete Role");
            System.out.println("7. Return to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter Role Name: ");
                    Role newRole = new Role();
                    newRole.setRoleName(scanner.nextLine());
                    try {
                    boolean added = roleService.addRole(newRole);
                    System.out.println(added ? "Role added." : "Failed to add.");
                    } catch (InvalidInputException e) {
                        System.err.println("Input Error: " + e.getMessage());
                    }
                    break;

                case 2:
                    List<Role> roles = roleService.getAllRoles();
                    if (roles.isEmpty()) {
                        System.out.println("No roles found.");
                    } else {
                        for (Role r : roles) {
                            r.display();
                            System.out.println("---------------------------");
                        }
                    }
                    break;

                case 3:
                    System.out.print("Enter Role ID: ");
                    try {
                    Role roleById = roleService.getRoleById(scanner.nextInt());
                        roleById.display();
                    } catch (RoleNotFoundException e) {
                        System.err.println(e.getMessage());
                    }
                    break;

                case 4:
                	System.out.print("Enter Role Name: ");
                	String inputName = scanner.nextLine();
                	try {
                	    Role roleByName = roleService.getRoleByName(inputName);               
                	    roleByName.display();
                	} catch (RoleNotFoundException e) {
                	    System.err.println(e.getMessage());
                	}
                    break;

                case 5:
                    System.out.print("Enter Role ID to update: ");
                    int updateId = scanner.nextInt();
                    scanner.nextLine();
                    try {
                    Role roleToUpdate = roleService.getRoleById(updateId);
                        System.out.print("New Role Name [" + roleToUpdate.getRoleName() + "]: ");
                        String newName = scanner.nextLine();
                        if (!newName.trim().isEmpty()) {
                            roleToUpdate.setRoleName(newName);
                        }
                        boolean updated = roleService.updateRole(roleToUpdate);
                        System.out.println(updated ? "Role updated." : "Update failed.");
                    } catch (RoleNotFoundException | InvalidInputException e) {
                        System.err.println(e.getMessage());
                    }
                    break;

                case 6:
                    System.out.print("Enter Role ID to delete: ");
                    try {
                    boolean deleted = roleService.deleteRole(scanner.nextInt());
                    System.out.println(deleted ? "Deleted." : "Deletion failed.");
                    } catch (RoleNotFoundException e) {
                        System.err.println(e.getMessage());
                    }
                    break;

                case 7:
                    return;

                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
    private static void adminManagementMenu(Scanner scanner, IAdminService adminService) {
        while (true) {
            System.out.println("\n----- Admin Management -----");
            System.out.println("1. Register Admin");
            System.out.println("2. Get Admin by ID");
            System.out.println("3. Get Admin by Username");
            System.out.println("4. Update Admin");
            System.out.println("5. Delete Admin");
            System.out.println("6. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1: // Register Admin
                    Admin newAdmin = new Admin();
                    System.out.print("First Name: ");
                    newAdmin.setFirstName(scanner.nextLine());
                    System.out.print("Last Name: ");
                    newAdmin.setLastName(scanner.nextLine());
                    System.out.print("Email: ");
                    newAdmin.setEmail(scanner.nextLine());
                    System.out.print("Phone Number: ");
                    newAdmin.setPhoneNumber(scanner.nextLine());
                    System.out.print("Username: ");
                    newAdmin.setUsername(scanner.nextLine());
                    System.out.print("Password: ");
                    newAdmin.setPasswordHash(scanner.nextLine());
                    System.out.print("Role ID: ");
                    newAdmin.setRoleID(scanner.nextInt());
                    newAdmin.setJoinDate(LocalDateTime.now());
                    try {
                    boolean added = adminService.registerAdmin(newAdmin);
                    System.out.println(added ? "Admin registered." : "Registration failed.");
                    } catch (InvalidInputException e) {
                        System.err.println("Input Error: " + e.getMessage());
                    }
                    break;

                case 2: // Get Admin by ID
                	System.out.print("Enter Admin ID: ");
                	try {
                	    Admin foundById = adminService.getAdminById(scanner.nextInt());
                	    foundById.display();
                	} catch (AdminNotFoundException e) {
                	    System.err.println(e.getMessage());
                	}

                    break;

                case 3: // Get Admin by Username
                	System.out.print("Enter Username: ");
                	try {
                	    Admin foundByUsername = adminService.getAdminByUsername(scanner.nextLine());
                	    foundByUsername.display();
                	} catch (AdminNotFoundException e) {
                	    System.err.println(e.getMessage());
                	}

                    break;

                case 4: // Update Admin
                    System.out.print("Enter Admin ID to update: ");
                    int updateId = scanner.nextInt();
                    scanner.nextLine();
                    try {
                    Admin existing = adminService.getAdminById(updateId);
 
                        System.out.println("Updating Admin: " + existing.getUsername());

                        System.out.print("New First Name [" + existing.getFirstName() + "]: ");
                        String fname = scanner.nextLine();
                        if (!fname.trim().isEmpty()) existing.setFirstName(fname);

                        System.out.print("New Last Name [" + existing.getLastName() + "]: ");
                        String lname = scanner.nextLine();
                        if (!lname.trim().isEmpty()) existing.setLastName(lname);

                        System.out.print("New Email [" + existing.getEmail() + "]: ");
                        String email = scanner.nextLine();
                        if (!email.trim().isEmpty()) existing.setEmail(email);

                        System.out.print("New Phone [" + existing.getPhoneNumber() + "]: ");
                        String phone = scanner.nextLine();
                        if (!phone.trim().isEmpty()) existing.setPhoneNumber(phone);

                        System.out.print("New Username [" + existing.getUsername() + "]: ");
                        String uname = scanner.nextLine();
                        if (!uname.trim().isEmpty()) existing.setUsername(uname);

                        System.out.print("New Password [hidden]: ");
                        String pwd = scanner.nextLine();
                        if (!pwd.trim().isEmpty()) existing.setPasswordHash(pwd);

                        System.out.print("New Role ID [" + existing.getRoleID() + "]: ");
                        String roleStr = scanner.nextLine();
                        if (!roleStr.trim().isEmpty()) existing.setRoleID(Integer.parseInt(roleStr));

                        boolean updated = adminService.updateAdmin(existing);
                        System.out.println(updated ? "Admin updated successfully." : "Update failed.");
                    } catch (AdminNotFoundException | InvalidInputException e) {
                        System.err.println(e.getMessage());
                    }
                    break;

                case 5: // Delete Admin
                	System.out.print("Enter Admin ID to delete: ");
                	try {
                	    boolean deleted = adminService.deleteAdmin(scanner.nextInt());
                	    System.out.println(deleted ? "Admin deleted." : "Deletion failed.");
                	} catch (AdminNotFoundException e) {
                	    System.err.println(e.getMessage());
                	}

                    break;

                case 6:
                    return;

                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
    private static void reportMenu(Scanner scanner, IReportService reportService) {
        while (true) {
            System.out.println("\n--- Admin Reports ---");
            System.out.println("1. Reservation History");
            System.out.println("2. Vehicle Utilization");
            System.out.println("3. Revenue Report");
            System.out.println("4. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    reportService.generateReservationHistory();
                    break;
                case 2:
                    reportService.generateVehicleUtilization();
                    break;
                case 3:
                    reportService.generateRevenueReport();
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid choice!");
            }
        }
    }

    
}
