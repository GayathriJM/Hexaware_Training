package com.cc.service;

import com.cc.dao.IAdminService;
import com.cc.entity.Admin;
import com.cc.exception.AdminNotFoundException;
import com.cc.exception.InvalidInputException;
import com.cc.util.DBConnUtil;
//import com.cc.util.DatabaseConnection;
import com.cc.util.HashUtil;

import java.sql.*;

public class AdminServiceImpl implements IAdminService {

    private Connection connection;

    public AdminServiceImpl() {
        this.connection = DBConnUtil.getConnection("resources/db.properties");
    }

    @Override
    public Admin getAdminById(int adminId) {
        String sql = "SELECT * FROM Admin WHERE AdminID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, adminId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapResultSetToAdmin(rs);
            }
            else {
                throw new AdminNotFoundException("Admin with ID " + adminId + " not found.");
            }
        } catch (SQLException e) {
            System.err.println("Error fetching admin by ID: " + e.getMessage());
            throw new AdminNotFoundException("Database error while fetching admin by ID.");
        }

    }

    @Override
    public Admin getAdminByUsername(String username) {
        String sql = "SELECT * FROM Admin WHERE Username = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapResultSetToAdmin(rs);
            }else {
                throw new AdminNotFoundException("Admin with username '" + username + "' not found.");
            }
        } catch (SQLException e) {
            System.err.println("Error fetching admin by username: " + e.getMessage());
            throw new AdminNotFoundException("Database error while fetching admin by username.");
        }
       
    }

    @Override
    public boolean registerAdmin(Admin admin) {
    	 if (isInvalidAdmin(admin)) {
    	        throw new InvalidInputException("Admin input is invalid. Required fields are missing.");
    	    }
        String sql = "INSERT INTO Admin (FirstName, LastName, Email, PhoneNumber, Username, PasswordHash, RoleID, JoinDate) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, admin.getFirstName());
            stmt.setString(2, admin.getLastName());
            stmt.setString(3, admin.getEmail());
            stmt.setString(4, admin.getPhoneNumber());
            stmt.setString(5, admin.getUsername());
            stmt.setString(6, HashUtil.hashPassword(admin.getPasswordHash()));
            stmt.setInt(7, admin.getRoleID());
            stmt.setTimestamp(8, Timestamp.valueOf(admin.getJoinDate()));
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.err.println("Error registering admin: " + e.getMessage());
        }
        return false;
    }

    @Override
    public boolean updateAdmin(Admin admin) {
        String sql = "UPDATE Admin SET FirstName = ?, LastName = ?, Email = ?, PhoneNumber = ?, Username = ?, PasswordHash = ?, RoleID = ? WHERE AdminID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, admin.getFirstName());
            stmt.setString(2, admin.getLastName());
            stmt.setString(3, admin.getEmail());
            stmt.setString(4, admin.getPhoneNumber());
            stmt.setString(5, admin.getUsername());
            stmt.setString(6, HashUtil.hashPassword(admin.getPasswordHash()));
            stmt.setInt(7, admin.getRoleID());
            stmt.setInt(8, admin.getAdminID());
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.err.println("Error updating admin: " + e.getMessage());
        }
        return false;
    }

    @Override
    public boolean deleteAdmin(int adminId) {
        String sql = "DELETE FROM Admin WHERE AdminID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, adminId);
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting admin: " + e.getMessage());
        }
        return false;
    }

    private Admin mapResultSetToAdmin(ResultSet rs) throws SQLException {
        Admin admin = new Admin();
        admin.setAdminID(rs.getInt("AdminID"));
        admin.setFirstName(rs.getString("FirstName"));
        admin.setLastName(rs.getString("LastName"));
        admin.setEmail(rs.getString("Email"));
        admin.setPhoneNumber(rs.getString("PhoneNumber"));
        admin.setUsername(rs.getString("Username"));
        admin.setPasswordHash(rs.getString("PasswordHash"));
        admin.setRoleID(rs.getInt("RoleID"));
        admin.setJoinDate(rs.getTimestamp("JoinDate").toLocalDateTime());
        return admin;
    }
    
    private boolean isInvalidAdmin(Admin admin) {
        return admin.getFirstName() == null || admin.getFirstName().trim().isEmpty()
            || admin.getEmail() == null || admin.getEmail().trim().isEmpty()
            || admin.getUsername() == null || admin.getUsername().trim().isEmpty()
            || admin.getPasswordHash() == null || admin.getPasswordHash().trim().isEmpty();
    }

}
