package com.cc.service;

import com.cc.dao.IReservationService;
import com.cc.entity.Reservation;
import com.cc.enums.ReservationStatus;
import com.cc.exception.InvalidInputException;
import com.cc.exception.ReservationException;
//import com.cc.util.DatabaseConnection;
import com.cc.util.DBConnUtil;
import com.cc.util.NotificationService;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ReservationServiceImpl implements IReservationService {

    private Connection connection;

    public ReservationServiceImpl() {
        this.connection = DBConnUtil.getConnection("resources/db.properties");
    }

    @Override
    public Reservation getReservationById(int reservationId) {
        String sql = "SELECT * FROM Reservation WHERE ReservationID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, reservationId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapResultSetToReservation(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching reservation by ID: " + e.getMessage());
        }
        return null;
    }

    @Override
    public List<Reservation> getReservationsByCustomerId(int customerId) {
        List<Reservation> reservations = new ArrayList<>();
        String sql = "SELECT * FROM Reservation WHERE CustomerID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, customerId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                reservations.add(mapResultSetToReservation(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching reservations by customer ID: " + e.getMessage());
        }
        return reservations;
    }

    @Override
    public boolean createReservation(Reservation reservation) {
    	 if (isInvalidReservation(reservation)) {
    	        throw new InvalidInputException("Reservation input is invalid.");
    	    }
    	 String conflictQuery = "SELECT * FROM Reservation WHERE VehicleID = ? "
                 + "AND Status IN ('Pending', 'Confirmed') "
                 + "AND ((? BETWEEN StartDate AND EndDate) "
                 + "OR (? BETWEEN StartDate AND EndDate) "
                 + "OR (? < StartDate AND ? > EndDate))";
    	 try (PreparedStatement conflictStmt = connection.prepareStatement(conflictQuery)) {
    	        conflictStmt.setInt(1, reservation.getVehicleID());
    	        conflictStmt.setTimestamp(2, Timestamp.valueOf(reservation.getStartDate()));
    	        conflictStmt.setTimestamp(3, Timestamp.valueOf(reservation.getEndDate()));
    	        conflictStmt.setTimestamp(4, Timestamp.valueOf(reservation.getStartDate()));
    	        conflictStmt.setTimestamp(5, Timestamp.valueOf(reservation.getEndDate()));

    	        ResultSet rs = conflictStmt.executeQuery();
    	        if (rs.next()) {
    	            throw new ReservationException("Conflict: Vehicle is already reserved during these dates.");
    	        }
    	    } catch (SQLException e) {
    	        System.err.println("Error checking reservation conflict: " + e.getMessage());
    	        return false;
    	    }
    	 
        String sql = "INSERT INTO Reservation (CustomerID, VehicleID, StartDate, EndDate, TotalCost, Status) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, reservation.getCustomerID());
            stmt.setInt(2, reservation.getVehicleID());
            stmt.setTimestamp(3, Timestamp.valueOf(reservation.getStartDate()));
            stmt.setTimestamp(4, Timestamp.valueOf(reservation.getEndDate()));
            stmt.setDouble(5, reservation.getTotalCost());
            stmt.setString(6, reservation.getStatus().name());
            int rows = stmt.executeUpdate();
            if (rows > 0) {
            	ResultSet generatedKeys = stmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    reservation.setReservationID(generatedKeys.getInt(1)); 
                }
                sendConfirmationNotification(reservation); 
                return true;
            }
            return false;

        } catch (SQLException e) {
            System.err.println("Error creating reservation: " + e.getMessage());
        }
        return false;
    }

    @Override
    public boolean updateReservation(Reservation reservation) {
    	 if (isInvalidReservation(reservation)) {
    	        throw new InvalidInputException("Reservation input is invalid.");
    	    }
        String sql = "UPDATE Reservation SET CustomerID = ?, VehicleID = ?, StartDate = ?, EndDate = ?, TotalCost = ?, Status = ? WHERE ReservationID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, reservation.getCustomerID());
            stmt.setInt(2, reservation.getVehicleID());
            stmt.setTimestamp(3, Timestamp.valueOf(reservation.getStartDate()));
            stmt.setTimestamp(4, Timestamp.valueOf(reservation.getEndDate()));
            stmt.setDouble(5, reservation.getTotalCost());
            stmt.setString(6, reservation.getStatus().name());
            stmt.setInt(7, reservation.getReservationID());
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.err.println("Error updating reservation: " + e.getMessage());
        }
        return false;
    }

    @Override
    public boolean cancelReservation(int reservationId) {
        String sql = "UPDATE Reservation SET Status = 'Cancelled' WHERE ReservationID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, reservationId);
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.err.println("Error cancelling reservation: " + e.getMessage());
        }
        return false;
    }

    private Reservation mapResultSetToReservation(ResultSet rs) throws SQLException {
        Reservation reservation = new Reservation();
        reservation.setReservationID(rs.getInt("ReservationID"));
        reservation.setCustomerID(rs.getInt("CustomerID"));
        reservation.setVehicleID(rs.getInt("VehicleID"));
        reservation.setStartDate(rs.getTimestamp("StartDate").toLocalDateTime());
        reservation.setEndDate(rs.getTimestamp("EndDate").toLocalDateTime());
        reservation.setTotalCost(rs.getDouble("TotalCost"));
        reservation.setStatus(ReservationStatus.valueOf(rs.getString("Status")));
        return reservation;
    }
    
    private boolean isInvalidReservation(Reservation r) {
        return r.getCustomerID() <= 0 || r.getVehicleID() <= 0 ||
               r.getStartDate() == null || r.getEndDate() == null ||
               r.getEndDate().isBefore(r.getStartDate()) ||
               r.getTotalCost() <= 0 || r.getStatus() == null;
    }
    
    private void sendConfirmationNotification(Reservation reservation) {
        String customerSql = "SELECT Email, PhoneNumber FROM Customer WHERE CustomerID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(customerSql)) {
            stmt.setInt(1, reservation.getCustomerID());
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String email = rs.getString("Email");
                String phone = rs.getString("PhoneNumber");

                NotificationService notify = new NotificationService();
                notify.sendReservationConfirmation(email, phone, reservation);
            }
        } catch (SQLException e) {
            System.err.println("Failed to fetch customer contact for notification: " + e.getMessage());
        }
    }
    
    public void sendReminderForReservation(int reservationId) {
        Reservation reservation = getReservationById(reservationId);
        if (reservation == null) {
            System.out.println("Reservation not found.");
            return;
        }

        String sql = "SELECT Email, PhoneNumber FROM Customer WHERE CustomerID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, reservation.getCustomerID());
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String email = rs.getString("Email");
                String phone = rs.getString("PhoneNumber");

                NotificationService notify = new NotificationService();
                notify.sendReminder(email, phone, reservation);  
            }
        } catch (SQLException e) {
            System.err.println("Error sending reminder: " + e.getMessage());
        }
    }


}