package com.cc.service;

import com.cc.dao.IReportService;
import com.cc.util.DBConnUtil;

import java.sql.*;

public class ReportServiceImpl implements IReportService {
    private Connection connection;

    public ReportServiceImpl() {
        this.connection = DBConnUtil.getConnection("resources/db.properties");
    }

    @Override
    public void generateReservationHistory() {
        System.out.println("\nReservation History Report:");
        String sql = "SELECT ReservationID, CustomerID, VehicleID, StartDate, EndDate, Status FROM Reservation ORDER BY StartDate DESC";
        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                System.out.println("--------------------------------------------");
                System.out.println("Reservation ID: " + rs.getInt("ReservationID"));
                System.out.println("Customer ID   : " + rs.getInt("CustomerID"));
                System.out.println("Vehicle ID    : " + rs.getInt("VehicleID"));
                System.out.println("Start Date    : " + rs.getTimestamp("StartDate"));
                System.out.println("End Date      : " + rs.getTimestamp("EndDate"));
                System.out.println("Status        : " + rs.getString("Status"));
            }

        } catch (SQLException e) {
            System.err.println("Error generating reservation history: " + e.getMessage());
        }
    }

    @Override
    public void generateVehicleUtilization() {
        System.out.println("\nVehicle Utilization Report:");
        String sql = "SELECT VehicleID, COUNT(*) AS Reservations FROM Reservation GROUP BY VehicleID ORDER BY Reservations DESC";
        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                System.out.println("Vehicle ID: " + rs.getInt("VehicleID") + " | Total Reservations: " + rs.getInt("Reservations"));
            }

        } catch (SQLException e) {
            System.err.println("Error generating vehicle utilization report: " + e.getMessage());
        }
    }

    @Override
    public void generateRevenueReport() {
        System.out.println("\nRevenue Report:");
        String actualRevenueQuery = "SELECT SUM(TotalCost) AS TotalRevenue FROM Reservation WHERE Status = 'Completed'";
        String forecastedRevenueQuery = "SELECT SUM(TotalCost) AS ForecastedRevenue FROM Reservation WHERE Status IN ('Completed', 'Confirmed')";
        try (
                PreparedStatement actualStmt = connection.prepareStatement(actualRevenueQuery);
                ResultSet actualRs = actualStmt.executeQuery();

                PreparedStatement forecastedStmt = connection.prepareStatement(forecastedRevenueQuery);
                ResultSet forecastedRs = forecastedStmt.executeQuery()
            ) {
                if (actualRs.next()) {
                    double actualRevenue = actualRs.getDouble("TotalRevenue");
                    System.out.printf("Actual Revenue (Completed Reservations Only): ₹%.2f%n", actualRevenue);
                }

                if (forecastedRs.next()) {
                    double forecastedRevenue = forecastedRs.getDouble("ForecastedRevenue");
                    System.out.printf("Forecasted Revenue (Completed + Confirmed): ₹%.2f%n", forecastedRevenue);
                }

            } catch (SQLException e) {
                System.err.println("Error generating revenue report: " + e.getMessage());
            }
    }
}

