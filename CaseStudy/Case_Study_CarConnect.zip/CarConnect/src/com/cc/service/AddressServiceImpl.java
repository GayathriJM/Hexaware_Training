package com.cc.service;

import com.cc.dao.IAddressService;
import com.cc.entity.Address;
import com.cc.enums.AddressType;
import com.cc.util.DBConnUtil;
//import com.cc.util.DatabaseConnection;
import com.cc.exception.InvalidInputException;
import com.cc.exception.AddressNotFoundException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AddressServiceImpl implements IAddressService {
    private Connection connection;

    public AddressServiceImpl() {
        this.connection = DBConnUtil.getConnection("resources/db.properties");
    }

    @Override
    public boolean addAddress(Address address) {
    	if (isInvalidAddress(address)) {
            throw new InvalidInputException("Street, City, ZIP Code, and Address Type must not be empty.");
        }
        String sql = "INSERT INTO Address (CustomerID, Street, City, State, ZIP, AddressType) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, address.getCustomerID());
            stmt.setString(2, address.getStreet());
            stmt.setString(3, address.getCity());
            stmt.setString(4, address.getState());
            stmt.setString(5, address.getZipCode());
            stmt.setString(6, address.getAddressType().name());
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.err.println("Error adding address: " + e.getMessage());
        }
        return false;
    }

    @Override
    public Address getAddressById(int addressId) {
        String sql = "SELECT * FROM Address WHERE AddressID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, addressId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapResultSetToAddress(rs);
            }else {
                throw new AddressNotFoundException("Address with ID " + addressId + " not found.");
            }
        } catch (SQLException e) {
            System.err.println("Error fetching address by ID: " + e.getMessage());
        }
        return null;
    }

    @Override
    public List<Address> getAddressesByCustomerId(int customerId) {
        List<Address> addresses = new ArrayList<>();
        String sql = "SELECT * FROM Address WHERE CustomerID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, customerId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                addresses.add(mapResultSetToAddress(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching addresses for customer: " + e.getMessage());
        }
        return addresses;
    }

    @Override
    public boolean updateAddress(Address address) {
    	if (isInvalidAddress(address)) {
            throw new InvalidInputException("Street, City, ZIP Code, and Address Type must not be empty.");
        }
        Address existing = getAddressById(address.getAddressID());
        if (existing == null) {
            throw new AddressNotFoundException("Address ID " + address.getAddressID() + " not found for update.");
        }
        String sql = "UPDATE Address SET Street = ?, City = ?, State = ?, ZIP = ?, AddressType = ? WHERE AddressID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, address.getStreet());
            stmt.setString(2, address.getCity());
            stmt.setString(3, address.getState());
            stmt.setString(4, address.getZipCode());
            stmt.setString(5, address.getAddressType().name());
            stmt.setInt(6, address.getAddressID());
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.err.println("Error updating address: " + e.getMessage());
        }
        return false;
    }

    @Override
    public boolean deleteAddress(int addressId) {
    	Address existing = getAddressById(addressId);
        if (existing == null) {
            throw new AddressNotFoundException("Address ID " + addressId + " not found.");
        }
        String sql = "DELETE FROM Address WHERE AddressID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, addressId);
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting address: " + e.getMessage());
        }
        return false;
    }

    private Address mapResultSetToAddress(ResultSet rs) throws SQLException {
        Address address = new Address();
        address.setAddressID(rs.getInt("AddressID"));
        address.setCustomerID(rs.getInt("CustomerID"));
        address.setStreet(rs.getString("Street"));
        address.setCity(rs.getString("City"));
        address.setState(rs.getString("State"));
        address.setZipCode(rs.getString("ZIP"));
        address.setAddressType(AddressType.valueOf(rs.getString("AddressType")));
        return address;
    }
    
    private boolean isInvalidAddress(Address address) {
        return address.getStreet() == null || address.getStreet().trim().isEmpty() ||
               address.getCity() == null || address.getCity().trim().isEmpty() ||
               address.getZipCode() == null || address.getZipCode().trim().isEmpty() ||
               address.getAddressType() == null;
    }
}
