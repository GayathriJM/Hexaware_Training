package com.cc.service;

import com.cc.dao.ICustomerService;
import com.cc.entity.Customer;
import com.cc.util.DBConnUtil;
import com.cc.util.HashUtil;
import com.cc.exception.InvalidInputException;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class CustomerServiceImpl implements ICustomerService {
    private Connection connection;

    public CustomerServiceImpl() {
        this.connection = DBConnUtil.getConnection("resources/db.properties");
    }

    @Override
    public Customer getCustomerById(int customerId) {
        String sql = "SELECT * FROM Customer WHERE CustomerID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, customerId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapResultSetToCustomer(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching customer by ID: " + e.getMessage());
        }
        return null;
    }

    @Override
    public Customer getCustomerByUsername(String username) {
        String sql = "SELECT * FROM Customer WHERE Username = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapResultSetToCustomer(rs);
            } else {
                System.out.println("Username '" + username + "' not found."); 
            }
        } catch (SQLException e) {
            System.err.println("Error fetching customer by username: " + e.getMessage());
        }
        return null;
    }

    @Override
    public boolean registerCustomer(Customer customer) {
    	if (isInvalidCustomer(customer)) {
            throw new InvalidInputException("Missing required fields during customer registration.");
        }
        String sql = "INSERT INTO Customer (FirstName, LastName, Email, PhoneNumber, Username, PasswordHash, RegistrationDate) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, customer.getFirstName());
            stmt.setString(2, customer.getLastName());
            stmt.setString(3, customer.getEmail());
            stmt.setString(4, customer.getPhoneNumber());
            stmt.setString(5, customer.getUsername());
            stmt.setString(6, HashUtil.hashPassword(customer.getPasswordHash())); 
            stmt.setTimestamp(7, Timestamp.valueOf(LocalDateTime.now()));
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.err.println("Error registering customer: " + e.getMessage());
        }
        return false;
    }

    @Override
    public boolean updateCustomer(Customer customer) {
    	 if (isInvalidCustomer(customer)) {
    	        throw new InvalidInputException("Missing required fields during customer update.");
    	    }
        String sql = "UPDATE Customer SET FirstName = ?, LastName = ?, Email = ?, PhoneNumber = ?, Username = ?, PasswordHash = ? WHERE CustomerID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, customer.getFirstName());
            stmt.setString(2, customer.getLastName());
            stmt.setString(3, customer.getEmail());
            stmt.setString(4, customer.getPhoneNumber());
            stmt.setString(5, customer.getUsername());
            stmt.setString(6, HashUtil.hashPassword(customer.getPasswordHash())); 
            stmt.setInt(7, customer.getCustomerID());
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.err.println("Error updating customer: " + e.getMessage());
        }
        return false;
    }

    @Override
    public boolean deleteCustomer(int customerId) {
        String sql = "DELETE FROM Customer WHERE CustomerID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, customerId);
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting customer: " + e.getMessage());
        }
        return false;
    }

    @Override
    public List<Customer> getAllCustomers() {
        List<Customer> customers = new ArrayList<>();
        String sql = "SELECT * FROM Customer";
        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                customers.add(mapResultSetToCustomer(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching all customers: " + e.getMessage());
        }
        return customers;
    }

    private Customer mapResultSetToCustomer(ResultSet rs) throws SQLException {
        Customer customer = new Customer();
        customer.setCustomerID(rs.getInt("CustomerID"));
        customer.setFirstName(rs.getString("FirstName"));
        customer.setLastName(rs.getString("LastName"));
        customer.setEmail(rs.getString("Email"));
        customer.setPhoneNumber(rs.getString("PhoneNumber"));
        customer.setUsername(rs.getString("Username"));
        customer.setPasswordHash(rs.getString("PasswordHash"));
        customer.setRegistrationDate(rs.getTimestamp("RegistrationDate").toLocalDateTime());
        return customer;
    }
    
    private boolean isInvalidCustomer(Customer customer) {
        return customer.getFirstName() == null || customer.getFirstName().trim().isEmpty() ||
               customer.getEmail() == null || customer.getEmail().trim().isEmpty() ||
               customer.getUsername() == null || customer.getUsername().trim().isEmpty() ||
               customer.getPasswordHash() == null || customer.getPasswordHash().trim().isEmpty();
    }
}
