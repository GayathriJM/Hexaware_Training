package com.cc.service;

import com.cc.dao.IRoleService;
import com.cc.entity.Role;
import com.cc.exception.InvalidInputException;
import com.cc.exception.RoleNotFoundException;
//import com.cc.util.DatabaseConnection;
import com.cc.util.DBConnUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RoleServiceImpl implements IRoleService {
    private Connection connection;

    public RoleServiceImpl() {
        this.connection = DBConnUtil.getConnection("resources/db.properties");
    }

    @Override
    public Role getRoleById(int roleId) {
        String sql = "SELECT * FROM Role WHERE RoleID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, roleId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapResultSetToRole(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching role by ID: " + e.getMessage());
        }
        throw new RoleNotFoundException("Role with ID " + roleId + " not found.");
    }

    @Override
    public Role getRoleByName(String roleName) {
        String sql = "SELECT * FROM Role WHERE RoleName = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, roleName);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapResultSetToRole(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching role by name: " + e.getMessage());
        }
        throw new RoleNotFoundException("Role '" + roleName + "' not found.");
    }

    @Override
    public boolean addRole(Role role) {
    	 if (isInvalidRole(role)) {
    	        throw new InvalidInputException("Role name cannot be empty.");
    	    }
        String sql = "INSERT INTO Role (RoleName) VALUES (?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, role.getRoleName());
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.err.println("Error adding role: " + e.getMessage());
        }
        return false;
    }

    @Override
    public boolean updateRole(Role role) {
    	 if (isInvalidRole(role)) {
    	        throw new InvalidInputException("Updated role name cannot be empty.");
    	    }
        String sql = "UPDATE Role SET RoleName = ? WHERE RoleID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, role.getRoleName());
            stmt.setInt(2, role.getRoleID());
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.err.println("Error updating role: " + e.getMessage());
        }
        return false;
    }

    @Override
    public boolean deleteRole(int roleId) {
        String sql = "DELETE FROM Role WHERE RoleID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, roleId);
            int rows = stmt.executeUpdate();
            if (rows == 0) {
                throw new RoleNotFoundException("Cannot delete. Role ID " + roleId + " not found.");
            }
            return true;
        } catch (SQLException e) {
            System.err.println("Error deleting role: " + e.getMessage());
        }
        return false;
    }
    
    @Override
    public List<Role> getAllRoles() {
        List<Role> roles = new ArrayList<>();
        String sql = "SELECT * FROM Role";
        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                roles.add(mapResultSetToRole(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching all roles: " + e.getMessage());
        }
        return roles;
    }

    private Role mapResultSetToRole(ResultSet rs) throws SQLException {
        Role role = new Role();
        role.setRoleID(rs.getInt("RoleID"));
        role.setRoleName(rs.getString("RoleName"));
        return role;
    }
    
    private boolean isInvalidRole(Role role) {
        return role.getRoleName() == null || role.getRoleName().trim().isEmpty();
    }

}
