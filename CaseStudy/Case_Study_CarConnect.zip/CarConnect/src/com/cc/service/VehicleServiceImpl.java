package com.cc.service;

import com.cc.dao.IVehicleService;
import com.cc.entity.Vehicle;
import com.cc.exception.InvalidInputException;
import com.cc.exception.VehicleNotFoundException;
//import com.cc.util.DatabaseConnection;
import com.cc.util.DBConnUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VehicleServiceImpl implements IVehicleService {
    private Connection connection;

    public VehicleServiceImpl() {
        this.connection = DBConnUtil.getConnection("resources/db.properties");
    }

    @Override
    public Vehicle getVehicleById(int vehicleId) {
        String sql = "SELECT * FROM Vehicle WHERE VehicleID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, vehicleId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return mapResultSetToVehicle(rs);
            } else {
                throw new VehicleNotFoundException("Vehicle with ID " + vehicleId + " not found.");
            }
        } catch (SQLException e) {
            System.err.println("Error fetching vehicle by ID: " + e.getMessage());
        }
        return null;
    }

    @Override
    public List<Vehicle> getAvailableVehicles() {
        List<Vehicle> vehicles = new ArrayList<>();
        String sql = "SELECT * FROM Vehicle WHERE Availability = TRUE";
        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                vehicles.add(mapResultSetToVehicle(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching available vehicles: " + e.getMessage());
        }
        return vehicles;
    }

    @Override
    public boolean addVehicle(Vehicle vehicle) {
    	 if (isInvalidVehicle(vehicle)) {
    	        throw new InvalidInputException("Model, Make, Registration, Year, or Rate cannot be empty or invalid.");
    	    }
        String sql = "INSERT INTO Vehicle (Model, Make, Year, Color, RegistrationNumber, DailyRate, Availability) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, vehicle.getModel());
            stmt.setString(2, vehicle.getMake());
            stmt.setInt(3, vehicle.getYear());
            stmt.setString(4, vehicle.getColor());
            stmt.setString(5, vehicle.getRegistrationNumber());
            stmt.setDouble(6, vehicle.getDailyRate());
            stmt.setBoolean(7, vehicle.isAvailability());

            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.err.println("Error adding vehicle: " + e.getMessage());
        }
        return false;
    }

    @Override
    public boolean updateVehicle(Vehicle vehicle) {
    	 if (isInvalidVehicle(vehicle)) {
    	        throw new InvalidInputException("Vehicle input fields are invalid for update.");
    	    }
        String sql = "UPDATE Vehicle SET Model = ?, Make = ?, Year = ?, Color = ?, RegistrationNumber = ?, DailyRate = ?, Availability = ? WHERE VehicleID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, vehicle.getModel());
            stmt.setString(2, vehicle.getMake());
            stmt.setInt(3, vehicle.getYear());
            stmt.setString(4, vehicle.getColor());
            stmt.setString(5, vehicle.getRegistrationNumber());
            stmt.setDouble(6, vehicle.getDailyRate());
            stmt.setBoolean(7, vehicle.isAvailability());
            stmt.setInt(8, vehicle.getVehicleID());

            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.err.println("Error updating vehicle: " + e.getMessage());
        }
        return false;
    }

    @Override
    public boolean removeVehicle(int vehicleId) {
    	if (getVehicleById(vehicleId) == null) {
            throw new VehicleNotFoundException("Vehicle ID " + vehicleId + " does not exist.");
        }
        String sql = "DELETE FROM Vehicle WHERE VehicleID = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, vehicleId);
            int rows = stmt.executeUpdate();
            return rows > 0;
        } catch (SQLException e) {
            System.err.println("Error removing vehicle: " + e.getMessage());
        }
        return false;
    }

    @Override
    public List<Vehicle> getAllVehicles() {
        List<Vehicle> vehicles = new ArrayList<>();
        String sql = "SELECT * FROM Vehicle";
        try (PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                vehicles.add(mapResultSetToVehicle(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching all vehicles: " + e.getMessage());
        }
        return vehicles;
    }

    private Vehicle mapResultSetToVehicle(ResultSet rs) throws SQLException {
        Vehicle vehicle = new Vehicle();
        vehicle.setVehicleID(rs.getInt("VehicleID"));
        vehicle.setModel(rs.getString("Model"));
        vehicle.setMake(rs.getString("Make"));
        vehicle.setYear(rs.getInt("Year"));
        vehicle.setColor(rs.getString("Color"));
        vehicle.setRegistrationNumber(rs.getString("RegistrationNumber"));
        vehicle.setDailyRate(rs.getDouble("DailyRate"));
        vehicle.setAvailability(rs.getBoolean("Availability"));
        return vehicle;
    }
    
    private boolean isInvalidVehicle(Vehicle v) {
        return v.getModel() == null || v.getModel().trim().isEmpty() ||
               v.getMake() == null || v.getMake().trim().isEmpty() ||
               v.getRegistrationNumber() == null || v.getRegistrationNumber().trim().isEmpty() ||
               v.getYear() <= 0 || v.getDailyRate() <= 0;
    }

}
