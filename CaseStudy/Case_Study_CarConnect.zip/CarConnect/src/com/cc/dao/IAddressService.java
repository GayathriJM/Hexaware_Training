package com.cc.dao;

import java.util.List;
import com.cc.entity.Address;

public interface IAddressService {
    boolean addAddress(Address address);
    Address getAddressById(int addressId);
    List<Address> getAddressesByCustomerId(int customerId);
    boolean updateAddress(Address address);
    boolean deleteAddress(int addressId);
}