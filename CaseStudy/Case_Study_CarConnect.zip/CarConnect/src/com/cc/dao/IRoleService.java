package com.cc.dao;

import com.cc.entity.Role;
import java.util.List;

public interface IRoleService {
    Role getRoleById(int roleId);
    Role getRoleByName(String roleName);
    boolean addRole(Role role);
    boolean updateRole(Role role);
    boolean deleteRole(int roleId);
    List<Role> getAllRoles();
}