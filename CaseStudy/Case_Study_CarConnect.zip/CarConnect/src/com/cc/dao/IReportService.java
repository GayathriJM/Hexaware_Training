package com.cc.dao;

public interface IReportService {
    void generateReservationHistory();
    void generateVehicleUtilization();
    void generateRevenueReport();
}
