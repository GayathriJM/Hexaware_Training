package com.cc.enums;

public enum AddressType {
    Home, Office, Other
}
