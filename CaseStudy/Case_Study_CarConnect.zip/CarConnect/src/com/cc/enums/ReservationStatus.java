package com.cc.enums;

public enum ReservationStatus {
    Pending,
    Confirmed,
    Completed,
    Cancelled
}

