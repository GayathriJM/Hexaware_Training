package com.cc.entity;

import java.time.LocalDateTime;
import com.cc.util.HashUtil;

public class Customer {
    private int customerID;
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;
    private String username;
    private String passwordHash;
    private LocalDateTime registrationDate;

    public Customer() {}

    public Customer(int customerID, String firstName, String lastName, String email, String phoneNumber,
                    String username, String password, LocalDateTime registrationDate) {
        this.customerID = customerID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.username = username;
        this.passwordHash = HashUtil.hashPassword(password);
        this.registrationDate = registrationDate;
    }



    public int getCustomerID() {
		return customerID;
	}

	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPasswordHash() {
		return passwordHash;
	}

	public void setPasswordHash(String passwordHash) {
		this.passwordHash = passwordHash;
	}

	public LocalDateTime getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(LocalDateTime registrationDate) {
		this.registrationDate = registrationDate;
	}

	public boolean authenticate(String password) {
        return this.passwordHash.equals(HashUtil.hashPassword(password));
    }
	
	public void display() {
	    System.out.println("ID: " + this.customerID);
	    System.out.println("Name: " + this.firstName + " " + this.lastName);
	    System.out.println("Email: " + this.email);
	    System.out.println("Phone: " + this.phoneNumber);
	    System.out.println("Username: " + this.username);
	    System.out.println("Registered: " + this.registrationDate);
	}

}