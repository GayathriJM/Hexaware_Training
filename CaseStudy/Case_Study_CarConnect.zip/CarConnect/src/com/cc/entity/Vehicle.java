package com.cc.entity;

public class Vehicle {
    private int vehicleID;
    private String model;
    private String make;
    private int year;
    private String color;
    private String registrationNumber;
    private double dailyRate;
    private boolean availability;

    public Vehicle() {}

    public Vehicle(int vehicleID, String model, String make, int year, String color,
                   String registrationNumber, double dailyRate, boolean availability) {
        this.vehicleID = vehicleID;
        this.model = model;
        this.make = make;
        this.year = year;
        this.color = color;
        this.registrationNumber = registrationNumber;
        this.dailyRate = dailyRate;
        this.availability = availability;
    }

    public int getVehicleID() {
        return vehicleID;
    }

    public void setVehicleID(int vehicleID) {
        this.vehicleID = vehicleID;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public void setRegistrationNumber(String registrationNumber) {
        this.registrationNumber = registrationNumber;
    }

    public double getDailyRate() {
        return dailyRate;
    }

    public void setDailyRate(double dailyRate) {
        this.dailyRate = dailyRate;
    }

    public boolean isAvailability() {
        return availability;
    }

    public void setAvailability(boolean availability) {
        this.availability = availability;
    }
    
    public void display() {
        System.out.println("Vehicle ID         : " + vehicleID);
        System.out.println("Model              : " + model);
        System.out.println("Make               : " + make);
        System.out.println("Year               : " + year);
        System.out.println("Color              : " + color);
        System.out.println("Registration Number: " + registrationNumber);
        System.out.printf("Daily Rate         : ₹%.2f%n", dailyRate);
        System.out.println("Availability       : " + (availability ? "Available" : "Not Available"));
    }

}