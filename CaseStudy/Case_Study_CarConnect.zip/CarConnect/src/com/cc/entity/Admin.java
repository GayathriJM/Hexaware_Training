package com.cc.entity;

import java.time.LocalDateTime;
import com.cc.util.HashUtil;

public class Admin {
    private int adminID;
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;
    private String username;
    private String passwordHash;
    private int roleID;
    private LocalDateTime joinDate;

    public Admin() {}

    public Admin(int adminID, String firstName, String lastName, String email,
                 String phoneNumber, String username, String passwordHash,
                 int roleID, LocalDateTime joinDate) {
        this.adminID = adminID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.username = username;
        this.passwordHash = passwordHash;
        this.roleID = roleID;
        this.joinDate = joinDate;
    }

    public int getAdminID() {
        return adminID;
    }

    public void setAdminID(int adminID) {
        this.adminID = adminID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public int getRoleID() {
        return roleID;
    }

    public void setRoleID(int roleID) {
        this.roleID = roleID;
    }

    public LocalDateTime getJoinDate() {
        return joinDate;
    }

    public void setJoinDate(LocalDateTime joinDate) {
        this.joinDate = joinDate;
    }

	public boolean authenticate(String password) {
        return this.passwordHash.equals(HashUtil.hashPassword(password));
    }
	
	public void display() {
	    System.out.println("Admin ID: " + adminID);
	    System.out.println("Name: " + firstName + " " + lastName);
	    System.out.println("Email: " + email);
	    System.out.println("Phone: " + phoneNumber);
	    System.out.println("Username: " + username);
	    System.out.println("Role ID: " + roleID);
	    System.out.println("Join Date: " + joinDate);
	}

}
