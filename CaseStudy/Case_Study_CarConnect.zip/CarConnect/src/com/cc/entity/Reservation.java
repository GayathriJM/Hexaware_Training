package com.cc.entity;

import java.time.LocalDateTime;
import com.cc.enums.ReservationStatus;

public class Reservation {
    private int reservationID;
    private int customerID;
    private int vehicleID;
    private LocalDateTime startDate;
    private LocalDateTime endDate;
    private double totalCost;
    private ReservationStatus status;

    public Reservation() {}

    public Reservation(int reservationID, int customerID, int vehicleID,
                       LocalDateTime startDate, LocalDateTime endDate,
                       double totalCost, ReservationStatus status) {
        this.reservationID = reservationID;
        this.customerID = customerID;
        this.vehicleID = vehicleID;
        this.startDate = startDate;
        this.endDate = endDate;
        this.totalCost = totalCost;
        this.status = status;
    }

    public int getReservationID() {
		return reservationID;
	}

	public void setReservationID(int reservationID) {
		this.reservationID = reservationID;
	}

	public int getCustomerID() {
		return customerID;
	}

	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}

	public int getVehicleID() {
		return vehicleID;
	}

	public void setVehicleID(int vehicleID) {
		this.vehicleID = vehicleID;
	}

	public LocalDateTime getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDateTime startDate) {
		this.startDate = startDate;
	}

	public LocalDateTime getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDateTime endDate) {
		this.endDate = endDate;
	}

	public double getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(double totalCost) {
		this.totalCost = totalCost;
	}

	public ReservationStatus getStatus() {
        return status;
    }

    public void setStatus(ReservationStatus status) {
        this.status = status;
    }
    
	public double calculateTotalCost(double dailyRate) {
        long milliseconds = java.time.Duration.between(startDate, endDate).toMillis();
        long days = milliseconds / (1000 * 60 * 60 * 24);
        if (days <= 0) days = 1; 
        return days * dailyRate;
    }
	
	public void display() {
        System.out.println("Reservation ID   : " + reservationID);
        System.out.println("Customer ID      : " + customerID);
        System.out.println("Vehicle ID       : " + vehicleID);
        System.out.println("Start Date       : " + startDate);
        System.out.println("End Date         : " + endDate);
        System.out.printf("Total Cost       : ₹%.2f%n", totalCost);
        System.out.println("Status           : " + status);
    }

}
