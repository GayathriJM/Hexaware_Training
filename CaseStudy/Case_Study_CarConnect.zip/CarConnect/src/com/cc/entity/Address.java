package com.cc.entity;

import com.cc.enums.AddressType;

public class Address {
    private int addressID;
    private int customerID;
    private String street;
    private String city;
    private String state;
    private String zipCode;
    private AddressType addressType; 

    public Address() {}

    public Address(int addressID, int customerID, String street, String city, String state, String zipCode, AddressType addressType) {
        this.addressID = addressID;
        this.customerID = customerID;
        this.street = street;
        this.city = city;
        this.state = state;
        this.zipCode = zipCode;
        this.addressType = addressType;
    }

    public int getAddressID() {
        return addressID;
    }

    public void setAddressID(int addressID) {
        this.addressID = addressID;
    }

    public int getCustomerID() {
        return customerID;
    }

    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public AddressType getAddressType() {
        return addressType;
    }

    public void setAddressType(AddressType addressType) {
        this.addressType = addressType;
    }
    
    public void display() {
        System.out.println("Address ID: " + this.addressID);
        System.out.println("Customer ID: " + this.customerID);
        System.out.println("Street: " + this.street);
        System.out.println("City: " + this.city);
        System.out.println("State: " + this.state);
        System.out.println("ZIP Code: " + this.zipCode);
        System.out.println("Address Type: " + this.addressType);
    }

    
}
